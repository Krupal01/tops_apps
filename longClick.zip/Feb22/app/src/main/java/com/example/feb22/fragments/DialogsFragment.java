package com.example.feb22.fragments;

import android.app.DatePickerDialog;
import android.app.TimePickerDialog;
import android.content.DialogInterface;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.fragment.app.Fragment;

import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.DatePicker;
import android.widget.TextView;
import android.widget.TimePicker;
import android.widget.Toast;

import com.example.feb22.R;
import com.example.feb22.databinding.FragmentDialogsBinding;

import java.sql.Time;
import java.util.Calendar;

/**
 * A simple {@link Fragment} subclass.
 * Use the {@link DialogsFragment#newInstance} factory method to
 * create an instance of this fragment.
 */
public class DialogsFragment extends Fragment {

    // TODO: Rename parameter arguments, choose names that match
    // the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
    private static final String ARG_PARAM1 = "param1";
    private static final String ARG_PARAM2 = "param2";

    // TODO: Rename and change types of parameters
    private String mParam1;
    private String mParam2;

    public DialogsFragment() {
        // Required empty public constructor
    }

    /**
     * Use this factory method to create a new instance of
     * this fragment using the provided parameters.
     *
     * @param param1 Parameter 1.
     * @param param2 Parameter 2.
     * @return A new instance of fragment DialogsFragment.
     */
    // TODO: Rename and change types and number of parameters
    public static DialogsFragment newInstance(String param1, String param2) {
        DialogsFragment fragment = new DialogsFragment();
        Bundle args = new Bundle();
        args.putString(ARG_PARAM1, param1);
        args.putString(ARG_PARAM2, param2);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            mParam1 = getArguments().getString(ARG_PARAM1);
            mParam2 = getArguments().getString(ARG_PARAM2);
        }
    }
    private FragmentDialogsBinding binding;
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        binding=FragmentDialogsBinding.inflate(inflater,container,false);
        return binding.getRoot();
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        binding.btnToast.setOnClickListener(v->{
//            Toast toast=Toast.makeText(getContext(),"This is Toast!!!",Toast.LENGTH_LONG);
//            toast.show();

            //Toast.makeText(getContext(), "This is Toast!!!", Toast.LENGTH_SHORT).show();

            // Custom Toast
            showCustomToast("This is Message");
        });

        binding.btnAlert.setOnClickListener(v->{
            AlertDialog.Builder builder=new AlertDialog.Builder(getContext());
            builder.setTitle(R.string.app_name);
            builder.setMessage("This is Message");
            builder.setIcon(R.mipmap.ic_launcher);
            builder.setCancelable(false);

            View customView=getLayoutInflater().inflate(R.layout.toast_layout,null);
            TextView tvMessage=customView.findViewById(R.id.tvMessage);
            tvMessage.setText("Test Message");
            builder.setView(customView);

            builder.setPositiveButton("Yes", (dialog, which) -> {
                 showCustomToast("Yes is Clicked!!!");
            });
            builder.setNegativeButton("No",(dialog, which) -> {
                showCustomToast("No is Clicked!!!");
            });
            builder.setNeutralButton("Cancel",(dialog, which) -> {
                showCustomToast("Cancel is Clicked!!!");
            });
            AlertDialog dialog = builder.create();
            dialog.show();
        });

        binding.btnDate.setOnClickListener(v->{
            Calendar calendar=Calendar.getInstance();
            int year=calendar.get(Calendar.YEAR);
            int month=calendar.get(Calendar.MONTH);
            int dayOfMonth=calendar.get(Calendar.DAY_OF_MONTH);
            DatePickerDialog.OnDateSetListener listener= (view1, selectedYear, selectedMonth, selectedDayOfMonth) -> {
                binding.btnDate.setText(selectedDayOfMonth+"/"+(selectedMonth+1)+"/"+selectedYear);
            };
            DatePickerDialog dialog=new DatePickerDialog(getContext(),listener,year,month,dayOfMonth);
            dialog.getDatePicker().setMinDate(calendar.getTimeInMillis());
            dialog.show();
        });

        binding.btnTime.setOnClickListener(v->{
            Calendar calendar=Calendar.getInstance();
            int hour=calendar.get(Calendar.HOUR);
            int minute=calendar.get(Calendar.MINUTE);

            TimePickerDialog.OnTimeSetListener listener= (view12, hourOfDay, min) -> {
                binding.btnTime.setText(hourOfDay+":"+min);
            };
            TimePickerDialog dialog=new TimePickerDialog(getContext(),listener,hour, minute, false);
            dialog.show();
        });
    }

    private void showCustomToast(String message) {
        Toast toast=new Toast(getContext());
        toast.setGravity(Gravity.CENTER,0,0);

        View customView=getLayoutInflater().inflate(R.layout.toast_layout,null);
        TextView tvMessage=customView.findViewById(R.id.tvMessage);
        tvMessage.setText(message);

        toast.setView(customView);
        toast.setDuration(Toast.LENGTH_LONG);
        toast.show();
    }
}