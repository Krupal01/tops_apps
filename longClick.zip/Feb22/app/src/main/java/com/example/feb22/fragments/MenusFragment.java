package com.example.feb22.fragments;

import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import android.util.Log;
import android.view.ContextMenu;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.PopupMenu;

import com.example.feb22.R;
import com.example.feb22.databinding.FragmentMenusBinding;

/**
 * A simple {@link Fragment} subclass.
 * Use the {@link MenusFragment#newInstance} factory method to
 * create an instance of this fragment.
 */
public class MenusFragment extends Fragment {

    // TODO: Rename parameter arguments, choose names that match
    // the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
    private static final String ARG_PARAM1 = "param1";
    private static final String ARG_PARAM2 = "param2";

    // TODO: Rename and change types of parameters
    private String mParam1;
    private String mParam2;

    public MenusFragment() {
        // Required empty public constructor
    }

    /**
     * Use this factory method to create a new instance of
     * this fragment using the provided parameters.
     *
     * @param param1 Parameter 1.
     * @param param2 Parameter 2.
     * @return A new instance of fragment MenusFragment.
     */
    // TODO: Rename and change types and number of parameters
    public static MenusFragment newInstance(String param1, String param2) {
        MenusFragment fragment = new MenusFragment();
        Bundle args = new Bundle();
        args.putString(ARG_PARAM1, param1);
        args.putString(ARG_PARAM2, param2);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            mParam1 = getArguments().getString(ARG_PARAM1);
            mParam2 = getArguments().getString(ARG_PARAM2);
        }
    }

    private FragmentMenusBinding binding;
    private static final String TAG = "MenusFragment";
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        // inside fragment only
        setHasOptionsMenu(true);
        binding=FragmentMenusBinding.inflate(inflater,container,false);
        return binding.getRoot();
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        registerForContextMenu(binding.btnContextMenu);

        binding.btnPopupMenu.setOnClickListener(v->{
            PopupMenu pMenu=new PopupMenu(getContext(),v);
            pMenu.getMenuInflater().inflate(R.menu.frag_menu,pMenu.getMenu());
            pMenu.setOnMenuItemClickListener(new PopupMenu.OnMenuItemClickListener() {
                @Override
                public boolean onMenuItemClick(MenuItem item) {
                    switch (item.getItemId()){
                        case R.id.action_file:
                            Log.i(TAG, "File menu is clicked");
                            return true;
                        case R.id.action_cut:
                            Log.i(TAG, "Cut menu is clicked");
                            return true;
                        case R.id.action_copy:
                            Log.i(TAG, "Copy menu is clicked");
                            return true;
                        case R.id.action_paste:
                            Log.i(TAG, "Paste menu is clicked");
                            return true;
                    }
                    return false;
                }
            });
            pMenu.show();
        });
    }

    @Override
    public void onCreateContextMenu(@NonNull ContextMenu menu, @NonNull View v, @Nullable ContextMenu.ContextMenuInfo menuInfo) {
        super.onCreateContextMenu(menu, v, menuInfo);
        MenuInflater inflater=getActivity().getMenuInflater();
        inflater.inflate(R.menu.frag_menu,menu);
    }

    @Override
    public boolean onContextItemSelected(@NonNull MenuItem item) {
        switch (item.getItemId()){
            case R.id.action_file:
                Log.i(TAG, "File menu is clicked");
                return true;
            case R.id.action_cut:
                Log.i(TAG, "Cut menu is clicked");
                return true;
            case R.id.action_copy:
                Log.i(TAG, "Copy menu is clicked");
                return true;
            case R.id.action_paste:
                Log.i(TAG, "Paste menu is clicked");
                return true;
        }
        return super.onContextItemSelected(item);
    }

    @Override
    public void onCreateOptionsMenu(@NonNull Menu menu, @NonNull MenuInflater inflater) {
        super.onCreateOptionsMenu(menu, inflater);
        inflater.inflate(R.menu.frag_menu,menu);
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        switch (item.getItemId()){
            case R.id.action_file:
                Log.i(TAG, "File menu is clicked");
                return true;
            case R.id.action_cut:
                Log.i(TAG, "Cut menu is clicked");
                return true;
            case R.id.action_copy:
                Log.i(TAG, "Copy menu is clicked");
                return true;
            case R.id.action_paste:
                Log.i(TAG, "Paste menu is clicked");
                return true;
        }
        return super.onOptionsItemSelected(item);
    }
}