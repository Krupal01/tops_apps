package com.example.feb22.recycler;

import android.graphics.Color;
import android.text.Layout;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.feb22.R;
import com.example.feb22.databinding.PersonRowItemBinding;

import java.util.ArrayList;

public class PersonAdapter extends RecyclerView.Adapter<PersonAdapter.PersonViewHolder> {
    // Step 1
    public interface OnPersonClickListener{
        void onPersonLongClick(int position);
        void onPersonClick(int position);
    }

    // Step 2
    private OnPersonClickListener listener;

    private ArrayList<Person> people;

    // Step 3
    public PersonAdapter(OnPersonClickListener listener){
        this.listener=listener;
    }

    public void setPeople(ArrayList<Person> people) {
        this.people = people;
    }

    @NonNull
    @Override
    public PersonViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        // Step 2
        LayoutInflater inflater= LayoutInflater.from(parent.getContext());
        View view=inflater.inflate(R.layout.person_row_item,parent,false);
        PersonViewHolder viewHolder=new PersonViewHolder(view);
        return viewHolder;
    }

    @Override
    public void onBindViewHolder(@NonNull PersonViewHolder holder, int position) {
        // Step 4
        Person person=people.get(position);
        holder.tvFirstName.setText("First Name : "+person.getFirstName());
        holder.tvLastName.setText("Last Name : "+person.getLastName());
        holder.tvEmail.setText("Email : "+person.getEmail());

        if(person.isColored()){
            holder.itemView.setBackgroundColor(Color.GREEN);
        }else{
            holder.itemView.setBackgroundColor(Color.TRANSPARENT);
        }

        // Long click event handler
        holder.itemView.setOnLongClickListener(new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(View v) {
                listener.onPersonLongClick(position);
                return false;
            }
        });

        holder.itemView.setOnClickListener(v->{
            listener.onPersonClick(position);
        });
    }

    @Override
    public int getItemCount() {
        // Step 1
        return people.size();
    }

    public class PersonViewHolder extends RecyclerView.ViewHolder {
        // Step 3
        private TextView tvFirstName, tvLastName, tvEmail;
        public PersonViewHolder(@NonNull View itemView) {
            super(itemView);
            tvFirstName=itemView.findViewById(R.id.tvFirstName);
            tvLastName=itemView.findViewById(R.id.tvLastName);
            tvEmail=itemView.findViewById(R.id.tvEmail);
        }
    }
}