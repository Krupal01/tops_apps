package com.example.feb22.fragments;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.example.feb22.R;
import com.example.feb22.WebviewActivity;
import com.example.feb22.adapter.HomeItemAdapter;
import com.example.feb22.adapter_Ex.ArrayAdapterFragment;
import com.example.feb22.model.HomeItem;
import com.example.feb22.recycler.RecyclerViewFragment;
import com.example.feb22.adapter_Ex.SimpleAdapterFragment;
import com.example.feb22.databinding.FragmentMainBinding;

import java.util.ArrayList;

/**
 * A simple {@link Fragment} subclass.
 * Use the {@link MainFragment#newInstance} factory method to
 * create an instance of this fragment.
 */
public class MainFragment extends Fragment
        implements View.OnClickListener, HomeItemAdapter.HomeItemClickListener {

    // TODO: Rename parameter arguments, choose names that match
    // the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
    private static final String ARG_PARAM1 = "param1";
    private static final String ARG_PARAM2 = "param2";

    // TODO: Rename and change types of parameters
    private String mParam1;
    private String mParam2;

    public MainFragment() {
        // Required empty public constructor
    }

    /**
     * Use this factory method to create a new instance of
     * this fragment using the provided parameters.
     *
     * @param param1 Parameter 1.
     * @param param2 Parameter 2.
     * @return A new instance of fragment MainFragment.
     */
    // TODO: Rename and change types and number of parameters
    public static MainFragment newInstance(String param1, String param2) {
        MainFragment fragment = new MainFragment();
        Bundle args = new Bundle();
        args.putString(ARG_PARAM1, param1);
        args.putString(ARG_PARAM2, param2);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            mParam1 = getArguments().getString(ARG_PARAM1);
            mParam2 = getArguments().getString(ARG_PARAM2);
        }
    }
    private FragmentMainBinding binding;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        binding=FragmentMainBinding.inflate(inflater,container,false);
        return binding.getRoot();
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        getActivity().setTitle(R.string.app_name);

        binding.recyclerView.setLayoutManager(new LinearLayoutManager(getContext()));


        ArrayList<HomeItem> items=new ArrayList<>();
        items.add(new HomeItem("Relative Layout",new RelativeFragment(),null));
        items.add(new HomeItem("Linear Layout",new LinearFragment(), null));
        items.add(new HomeItem("Webview",null,WebviewActivity.class));
        items.add(new HomeItem("RecyclerView",new RecyclerViewFragment(),null));
        items.add(new HomeItem("Cutom Layout", new CustomLayoutFragment(),null));
        items.add(new HomeItem("Dialogs", new DialogsFragment(),null));
        items.add(new HomeItem("Menus", new MenusFragment(),null));

        /*HomeItemAdapter adapter=new HomeItemAdapter(new HomeItemAdapter.HomeItemClickListener() {
            @Override
            public void onHomeItemClick(HomeItem item) {

            }
        });*/
        HomeItemAdapter adapter=new HomeItemAdapter(this);
        adapter.setItems(items);

        binding.recyclerView.setAdapter(adapter);


        /*binding.btnRelative.setOnClickListener(this);
        binding.btnLinear.setOnClickListener(this);
        binding.btnTable.setOnClickListener(this);
        binding.btnGridLayout.setOnClickListener(this);
        binding.btnCustom.setOnClickListener(this);
        binding.btnEditText.setOnClickListener(this);
        binding.btnRadio.setOnClickListener(this);
        binding.btnCheckbox.setOnClickListener(this);
        binding.btnSeekbar.setOnClickListener(this);
        binding.btnWebview.setOnClickListener(this);
        binding.btnSpinner.setOnClickListener(this);
        binding.btnListView.setOnClickListener(this);
        binding.btnArrayAdapter.setOnClickListener(this);
        binding.btnSimpleAdapter.setOnClickListener(this);
        binding.btnRecyclerView.setOnClickListener(this);*/
    }

    @Override
    public void onClick(View v) {
        /*switch (v.getId()){
            case R.id.btnRelative:
                switchFragment(new RelativeFragment());
                break;
            case R.id.btnLinear:
                switchFragment(new LinearFragment());
                break;
            case R.id.btnTable:
                switchFragment(new TableFragment());
                break;
            case R.id.btnGridLayout:
                switchFragment(new GridLayoutFragment());
                break;
            case R.id.btnCustom:
                switchFragment(new CustomLayoutFragment());
                break;
            case R.id.btnEditText:
                switchFragment(new EditTextFragment());
                break;

            case R.id.btnRadio:
                switchFragment(new RadioFragment());
                break;
            case R.id.btnCheckbox:
                switchFragment(new CheckboxFragment());
                break;
            case R.id.btnSeekbar:
                switchFragment(new SeekbarFragment());
                break;
            case R.id.btnSpinner:
                switchFragment(new SpinnerFragment());
                break;
            case R.id.btnListView:
                switchFragment(new ListViewFragment());
                break;
            case R.id.btnWebview:
                hangeActivcity(WebviewActivity.class);
                break;
            case R.id.btnArrayAdapter:
                switchFragment(new ArrayAdapterFragment());
                break;
            case R.id.btnSimpleAdapter:
                switchFragment(new SimpleAdapterFragment());
                break;

            case R.id.btnRecyclerView:
                switchFragment(new RecyclerViewFragment());
                break;
        }*/
    }

    private void changeActivity(Class<? extends Activity> theClass){
        Intent intent=new Intent(getContext(), theClass);
        startActivity(intent);
    }

    private void switchFragment(Fragment fragment) {
        getFragmentManager()
                .beginTransaction()
                .replace(R.id.frame,fragment)
                .addToBackStack(MainFragment.class.getName())
                .commit();
    }

    @Override
    public void onHomeItemClick(HomeItem item) {
        if(item.getFragment()==null){
            changeActivity(item.getActivityClass());
        }else{
            switchFragment(item.getFragment());
        }
    }
}