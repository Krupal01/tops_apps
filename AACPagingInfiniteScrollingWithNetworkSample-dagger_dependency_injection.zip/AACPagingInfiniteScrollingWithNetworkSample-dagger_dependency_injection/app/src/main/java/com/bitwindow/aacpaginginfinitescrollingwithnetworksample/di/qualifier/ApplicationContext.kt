package com.bitwindow.aacpaginginfinitescrollingwithnetworksample.di.qualifier

import javax.inject.Qualifier

@Qualifier
annotation class ApplicationContext