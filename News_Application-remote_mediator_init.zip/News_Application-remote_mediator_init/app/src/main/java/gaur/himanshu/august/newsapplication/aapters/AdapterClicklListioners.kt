package gaur.himanshu.august.newsapplication.aapters

import gaur.himanshu.august.newsapplication.retrofit.responce.Article

interface AdapterClicklListioners {

    fun clickListioners(article: Article)

}