package gaur.himanshu.august.newsapplication

object Constants {
    const val API_KEY = "436a7b507ee5433bafa1ad67c8eff93b"
}