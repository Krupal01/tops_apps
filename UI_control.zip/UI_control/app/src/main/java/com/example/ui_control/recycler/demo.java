package com.example.ui_control.recycler;

public class demo {
    private String name;
    private String posi;
    private String number;

    public demo(String name, String posi, String number) {
        this.name = name;
        this.posi = posi;
        this.number = number;
    }

    public String getName() {
        return name;
    }

    public String getPosi() {
        return posi;
    }

    public String getNumber() {
        return number;
    }
}
