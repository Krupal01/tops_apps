package com.example.ui_control.Whatapp;

public class person {
    private int src;
    private String name;

    public person(int src, String name) {
        this.src = src;
        this.name = name;
    }

    public person() {
    }

    public int getSrc() {
        return src;
    }

    public String getName() {
        return name;
    }
}
