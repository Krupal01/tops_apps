package com.example.assignmenttopsonline.parse_api.railway;

public class RailwayData {

    String year,broad_gauge,metre_gauge,narrow_gauge,total;

    public RailwayData(String year, String broad_gauge, String metre_gauge, String narrow_gauge, String total) {
        this.year = year;
        this.broad_gauge = broad_gauge;
        this.metre_gauge = metre_gauge;
        this.narrow_gauge = narrow_gauge;
        this.total = total;
    }

    @Override
    public String toString() {
        return "RailwayData{" +
                "year='" + year + '\'' +
                ", broad_gauge='" + broad_gauge + '\'' +
                ", metre_gauge='" + metre_gauge + '\'' +
                ", narrow_gauge='" + narrow_gauge + '\'' +
                ", total='" + total + '\'' +
                '}';
    }

    public String getYear() {
        return year;
    }

    public void setYear(String year) {
        this.year = year;
    }

    public String getBroad_gauge() {
        return broad_gauge;
    }

    public void setBroad_gauge(String broad_gauge) {
        this.broad_gauge = broad_gauge;
    }

    public String getMetre_gauge() {
        return metre_gauge;
    }

    public void setMetre_gauge(String metre_gauge) {
        this.metre_gauge = metre_gauge;
    }

    public String getNarrow_gauge() {
        return narrow_gauge;
    }

    public void setNarrow_gauge(String narrow_gauge) {
        this.narrow_gauge = narrow_gauge;
    }

    public String getTotal() {
        return total;
    }

    public void setTotal(String total) {
        this.total = total;
    }
}
