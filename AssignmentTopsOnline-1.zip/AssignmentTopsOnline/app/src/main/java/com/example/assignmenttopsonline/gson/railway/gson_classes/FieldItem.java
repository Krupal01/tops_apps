package com.example.assignmenttopsonline.gson.railway.gson_classes;

import com.google.gson.annotations.SerializedName;

public class FieldItem{

	@SerializedName("name")
	private String name;

	@SerializedName("id")
	private String id;

	@SerializedName("type")
	private String type;

	public String getName(){
		return name;
	}

	public String getId(){
		return id;
	}

	public String getType(){
		return type;
	}

	@Override
 	public String toString(){
		return 
			"FieldItem{" + 
			"name = '" + name + '\'' + 
			",id = '" + id + '\'' + 
			",type = '" + type + '\'' + 
			"}";
		}
}