package com.example.assignmenttopsonline.gson.cricket.gson_classes;

import com.google.gson.annotations.SerializedName;

public class MatchesItem{

	@Override
	public String toString() {
		return "MatchesItem{" +
				"date='" + date + '\'' +
				", uniqueId=" + uniqueId +
				", squad=" + squad +
				", dateTimeGMT='" + dateTimeGMT + '\'' +
				", matchStarted=" + matchStarted +
				", type='" + type + '\'' +
				", team2='" + team2 + '\'' +
				", team1='" + team1 + '\'' +
				", tossWinnerTeam='" + tossWinnerTeam + '\'' +
				", winnerTeam='" + winnerTeam + '\'' +
				'}';
	}

	@SerializedName("date")
	private String date;

	@SerializedName("unique_id")
	private int uniqueId;

	@SerializedName("squad")
	private boolean squad;

	@SerializedName("dateTimeGMT")
	private String dateTimeGMT;

	@SerializedName("matchStarted")
	private boolean matchStarted;

	@SerializedName("type")
	private String type;

	@SerializedName("team-2")
	private String team2;

	@SerializedName("team-1")
	private String team1;

	@SerializedName("toss_winner_team")
	private String tossWinnerTeam;

	@SerializedName("winner_team")
	private String winnerTeam;

	public String getDate(){
		return date;
	}

	public int getUniqueId(){
		return uniqueId;
	}

	public boolean isSquad(){
		return squad;
	}

	public String getDateTimeGMT(){
		return dateTimeGMT;
	}

	public boolean isMatchStarted(){
		return matchStarted;
	}

	public String getType(){
		return type;
	}

	public String getTeam2(){
		return team2;
	}

	public String getTeam1(){
		return team1;
	}

	public String getTossWinnerTeam(){
		return tossWinnerTeam;
	}

	public String getWinnerTeam(){
		return winnerTeam;
	}
}