package com.example.assignmenttopsonline.file_from_server;

import androidx.appcompat.app.AppCompatActivity;

import android.app.ProgressDialog;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.AsyncTask;
import android.os.Bundle;
import android.widget.Toast;

import com.example.assignmenttopsonline.R;
import com.example.assignmenttopsonline.databinding.ActivityFileFromServerBinding;

import java.io.BufferedInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;

public class FileFromServerActivity extends AppCompatActivity {
    private ActivityFileFromServerBinding binding;
    private String theUrl="https://homepages.cae.wisc.edu/~ece533/images/frymire.png";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding=ActivityFileFromServerBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        binding.btnFileFromServer.setOnClickListener(v -> {
            new ImageDownload(this).execute(theUrl);
        });

        // do not make separate async task class
    }
    private class ImageDownload extends AsyncTask<String,Void, Bitmap>{

        private FileFromServerActivity activity;
        public ImageDownload(FileFromServerActivity activity){
            this.activity=activity;
            pd=new ProgressDialog(activity);
        }
        private HttpURLConnection conn;
        private ProgressDialog pd;

        @Override
        protected void onPreExecute() {

            pd.setMessage("Downloading");
            pd.show();

        }

        @Override
        protected Bitmap doInBackground(String... strings) {
            try {
                URL url=new URL(strings[0]);
                conn= (HttpURLConnection) url.openConnection();
                InputStream inputStream=new BufferedInputStream(conn.getInputStream());

                Bitmap temp= BitmapFactory.decodeStream(inputStream);
                return temp;

            } catch (IOException e) {
                e.printStackTrace();
            }finally{
                conn.disconnect();
            }
            return null;
        }

        @Override
        protected void onPostExecute(Bitmap bitmap) {
            if (pd.isShowing()) {
                pd.dismiss();
            }

            if(bitmap!=null){
               binding.imageViewFromServer.setImageBitmap(bitmap);
               Toast.makeText(getApplicationContext(),"Image Downloaded SuccessFully",Toast.LENGTH_SHORT).show();
           }else{
               Toast.makeText(getApplicationContext(),"Image Download Fail",Toast.LENGTH_SHORT).show();
           }
        }

        @Override
        protected void onProgressUpdate(Void... values) {
            super.onProgressUpdate(values);
        }
    }
}