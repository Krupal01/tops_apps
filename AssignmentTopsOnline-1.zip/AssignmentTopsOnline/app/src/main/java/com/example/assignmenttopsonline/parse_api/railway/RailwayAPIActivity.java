package com.example.assignmenttopsonline.parse_api.railway;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;

import android.app.ProgressDialog;
import android.os.Bundle;
import android.util.Log;

import com.example.assignmenttopsonline.R;
import com.example.assignmenttopsonline.databinding.ActivityRailwayApiactivityBinding;
import com.example.assignmenttopsonline.parse_api.MyAsyncTask;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;

public class RailwayAPIActivity extends AppCompatActivity implements MyAsyncTask.onResponseListener {
    private ActivityRailwayApiactivityBinding binding;
    private ProgressDialog pd;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setTitle("Total Railway Line Expansion");
        binding=ActivityRailwayApiactivityBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        pd=ProgressDialog.show(this,"Wait","Fetching Data");

        MyAsyncTask asyncTask=new MyAsyncTask();
        asyncTask.setUrl("https://api.data.gov.in/resource/7be53d59-08e0-4247-b7c5-1a9fb220720a?api-key=579b464db66ec23bdd000001cdd3946e44ce4aad7209ff7b23ac571b&format=json&offset=0&limit=1000");
        asyncTask.setListener(this);
        asyncTask.execute();

        binding.recyclerViewRailway.setLayoutManager(new LinearLayoutManager(this));


    }

    @Override
    public void onResponse(String response) {
        ArrayList<RailwayData>dataArrayList=new ArrayList<>();

        try{

            //there is object first .. and array inside the object so.... take response in object

            JSONObject masterObject=new JSONObject(response);
            JSONArray jsonArray=masterObject.getJSONArray("records");
            for(int i=0;i<jsonArray.length();i++){
                JSONObject object=jsonArray.getJSONObject(i);

                String year=object.getString("_year");
                String board_gauge=object.getString("broad_gauge");
                String metre_gauge=object.getString("metre_gauge");
                String narrow_gauge=object.getString("narrow_gauge");
                String total=object.getString("_total");

                RailwayData data=new RailwayData(year,board_gauge,metre_gauge,narrow_gauge,total);
                dataArrayList.add(data);

            }

            RailwayAdapter adapter=new RailwayAdapter(dataArrayList);

            binding.recyclerViewRailway.setAdapter(adapter);

        }catch (JSONException e){
            Log.i("myError",e.toString());
        }


    }
}