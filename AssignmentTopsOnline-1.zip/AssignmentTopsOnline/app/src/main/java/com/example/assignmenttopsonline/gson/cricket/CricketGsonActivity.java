package com.example.assignmenttopsonline.gson.cricket;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.util.Log;

import com.example.assignmenttopsonline.databinding.ActivityCricketGsonBinding;
import com.example.assignmenttopsonline.gson.cricket.gson_classes.Cricket;
import com.google.gson.Gson;

import org.jetbrains.annotations.NotNull;

import java.io.IOException;

import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;
import okhttp3.ResponseBody;

public class CricketGsonActivity extends AppCompatActivity {
    private ActivityCricketGsonBinding binding;
    private OkHttpClient client=new OkHttpClient();
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding=ActivityCricketGsonBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        String url="https://cricapi.com/api/matches?apikey=cZGPAxS3TQNPuiG3DmK6slHvyEk2";


        getPerson(url);
    }
        //lets use okhttp for response

    private void getPerson(String url) {
        Request request=new Request.Builder()
                .url(url)
                .build();
        client.newCall(request).enqueue(new Callback() {
            @Override
            public void onFailure(@NotNull Call call, @NotNull IOException e) {
                e.printStackTrace();
            }

            @Override
            public void onResponse(@NotNull Call call, @NotNull Response response) throws IOException {
                if(response.isSuccessful()){

                    //important to run this on separate thread

                    new Thread(() -> {
                        Gson gson=new Gson();
                        Cricket cricket=gson.fromJson(response.body().charStream(),Cricket.class);

                        //run every binding task on ui thread

                        runOnUiThread(new Runnable() {
                            @Override
                            public void run() {
                                binding.tvCricketGson.setText(cricket.toString());
                            }
                        });

                        Log.i("Response",cricket.toString());
                    }).start();

                }else{
                    ResponseBody responseBody=response.body();
                    String body=responseBody.string();
                    Log.i("Response",body);
                }
            }
        });

    }
}