package com.example.assignmenttopsonline.upload_profile_form_gallery;

import androidx.activity.result.ActivityResultCallback;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Bundle;
import android.provider.OpenableColumns;

import com.example.assignmenttopsonline.databinding.ActivityPictureFromSdactivityBinding;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;

public class PictureFromSDActivity extends AppCompatActivity {
    private ActivityPictureFromSdactivityBinding binding;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding=ActivityPictureFromSdactivityBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        ActivityResultLauncher<String>launcher=registerForActivityResult(
                new ActivityResultContracts.GetContent(), new ActivityResultCallback<Uri>() {
                    @Override
                    public void onActivityResult(Uri result) {
                        if(result!=null){
                            String newPath=copyFileToInternal(result);
                            if(newPath!=null){
                                Bitmap photo= BitmapFactory.decodeFile(newPath);
                                binding.imageViewFromSd.setImageBitmap(photo);
                            }
                        }
                    }
                }
        );

        binding.btnFromSD.setOnClickListener(v -> {
            launcher.launch("image/*");
        });
    }

    private String copyFileToInternal(Uri result) {
        Cursor cursor=getContentResolver().query(result,new String[]{OpenableColumns.DISPLAY_NAME,OpenableColumns.SIZE},null,null,null);
        cursor.moveToFirst();

        String displayName=cursor.getString(cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME));
        long size=cursor.getLong(cursor.getColumnIndex(OpenableColumns.SIZE));
        File file=new File(getFilesDir()+"/"+displayName);
        try{
            FileOutputStream outputStream=new FileOutputStream(file);
            InputStream inputStream=getContentResolver().openInputStream(result);

            byte buffers[]=new byte[1024];
            int read;
            while((read=inputStream.read(buffers))!=-1){
                outputStream.write(buffers,0,read);
            }
            inputStream.close();
            outputStream.close();
            return file.getPath();
        }catch (Exception e){
            e.printStackTrace();
        }
        return null;
    }
}