package com.example.assignmenttopsonline.gson.railway.gson_classes;

import java.util.List;
import com.google.gson.annotations.SerializedName;

public class Railway{

	@SerializedName("records")
	private List<RecordsItem> records;

	@SerializedName("source")
	private String source;

	@SerializedName("title")
	private String title;

	@SerializedName("external_ws_url")
	private String externalWsUrl;

	@SerializedName("total")
	private int total;

	@SerializedName("external_ws")
	private String externalWs;

	@SerializedName("limit")
	private int limit;

	@SerializedName("index_name")
	private String indexName;

	@SerializedName("sector")
	private List<String> sector;

	@SerializedName("offset")
	private String offset;

	@SerializedName("org")
	private List<String> org;

	@SerializedName("created")
	private int created;

	@SerializedName("org_type")
	private String orgType;

	@SerializedName("count")
	private int count;

	@SerializedName("active")
	private String active;

	@SerializedName("message")
	private String message;

	@SerializedName("version")
	private String version;

	@SerializedName("visualizable")
	private String visualizable;

	@SerializedName("field")
	private List<FieldItem> field;

	@SerializedName("catalog_uuid")
	private String catalogUuid;

	@SerializedName("created_date")
	private String createdDate;

	@SerializedName("updated_date")
	private String updatedDate;

	@SerializedName("updated")
	private int updated;

	@SerializedName("desc")
	private String desc;

	@SerializedName("status")
	private String status;

	public List<RecordsItem> getRecords(){
		return records;
	}

	public String getSource(){
		return source;
	}

	public String getTitle(){
		return title;
	}

	public String getExternalWsUrl(){
		return externalWsUrl;
	}

	public int getTotal(){
		return total;
	}

	public String getExternalWs(){
		return externalWs;
	}

	public int getLimit(){
		return limit;
	}

	public String getIndexName(){
		return indexName;
	}

	public List<String> getSector(){
		return sector;
	}

	public String getOffset(){
		return offset;
	}

	public List<String> getOrg(){
		return org;
	}

	public int getCreated(){
		return created;
	}

	public String getOrgType(){
		return orgType;
	}

	public int getCount(){
		return count;
	}

	public String getActive(){
		return active;
	}

	public String getMessage(){
		return message;
	}

	public String getVersion(){
		return version;
	}

	public String getVisualizable(){
		return visualizable;
	}

	public List<FieldItem> getField(){
		return field;
	}

	public String getCatalogUuid(){
		return catalogUuid;
	}

	public String getCreatedDate(){
		return createdDate;
	}

	public String getUpdatedDate(){
		return updatedDate;
	}

	public int getUpdated(){
		return updated;
	}

	public String getDesc(){
		return desc;
	}

	public String getStatus(){
		return status;
	}

	@Override
 	public String toString(){
		return 
			"Railway{" + 
			"records = '" + records + '\'' + 
			",source = '" + source + '\'' + 
			",title = '" + title + '\'' + 
			",external_ws_url = '" + externalWsUrl + '\'' + 
			",total = '" + total + '\'' + 
			",external_ws = '" + externalWs + '\'' + 
			",limit = '" + limit + '\'' + 
			",index_name = '" + indexName + '\'' + 
			",sector = '" + sector + '\'' + 
			",offset = '" + offset + '\'' + 
			",org = '" + org + '\'' + 
			",created = '" + created + '\'' + 
			",org_type = '" + orgType + '\'' + 
			",count = '" + count + '\'' + 
			",active = '" + active + '\'' + 
			",message = '" + message + '\'' + 
			",version = '" + version + '\'' + 
			",visualizable = '" + visualizable + '\'' + 
			",field = '" + field + '\'' + 
			",catalog_uuid = '" + catalogUuid + '\'' + 
			",created_date = '" + createdDate + '\'' + 
			",updated_date = '" + updatedDate + '\'' + 
			",updated = '" + updated + '\'' + 
			",desc = '" + desc + '\'' + 
			",status = '" + status + '\'' + 
			"}";
		}
}