package com.example.assignmenttopsonline.retrofit;

import java.util.List;

import retrofit2.Call;
import retrofit2.http.GET;

public interface ProjectService {

    String url="https://simplifiedcoding.net/demos/";

    @GET("marvel")
    Call<List<HeroData>> getHeroData();
}
