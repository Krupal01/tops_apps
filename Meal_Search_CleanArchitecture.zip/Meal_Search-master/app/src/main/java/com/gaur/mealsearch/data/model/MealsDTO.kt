package com.gaur.mealsearch.data.model

data class MealsDTO(
    val meals: List<MealDTO>?
)