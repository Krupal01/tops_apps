package com.gaur.mealsearch.common

object Constants {

    const val BASE_URL = "https://www.themealdb.com/"

}