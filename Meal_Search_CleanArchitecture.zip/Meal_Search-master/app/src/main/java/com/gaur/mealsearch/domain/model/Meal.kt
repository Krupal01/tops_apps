package com.gaur.mealsearch.domain.model

data class Meal(
    val id: String,
    val name: String,
    val image: String
)