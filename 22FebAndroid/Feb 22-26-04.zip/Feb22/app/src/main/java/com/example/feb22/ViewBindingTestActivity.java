package com.example.feb22;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.util.Log;

import com.example.feb22.databinding.ActivityViewBindingTestBinding;

public class ViewBindingTestActivity extends AppCompatActivity {
    private ActivityViewBindingTestBinding binding;
    private static final String TAG = "ViewBindingTestActivity";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        binding=ActivityViewBindingTestBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        binding.btnSubmit.setOnClickListener(v->{
            String msg=binding.etMessage.getText().toString();
            Log.i(TAG, msg);

        });
    }
}