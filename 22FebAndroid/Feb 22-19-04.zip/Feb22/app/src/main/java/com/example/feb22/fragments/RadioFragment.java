package com.example.feb22.fragments;

import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.RadioGroup;

import com.example.feb22.R;
import com.example.feb22.databinding.FragmentRadioBinding;

/**
 * A simple {@link Fragment} subclass.
 * Use the {@link RadioFragment#newInstance} factory method to
 * create an instance of this fragment.
 */
public class RadioFragment extends Fragment implements TextWatcher, RadioGroup.OnCheckedChangeListener {

    // TODO: Rename parameter arguments, choose names that match
    // the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
    private static final String ARG_PARAM1 = "param1";
    private static final String ARG_PARAM2 = "param2";

    // TODO: Rename and change types of parameters
    private String mParam1;
    private String mParam2;

    public RadioFragment() {
        // Required empty public constructor
    }

    /**
     * Use this factory method to create a new instance of
     * this fragment using the provided parameters.
     *
     * @param param1 Parameter 1.
     * @param param2 Parameter 2.
     * @return A new instance of fragment RadioFragment.
     */
    // TODO: Rename and change types and number of parameters
    public static RadioFragment newInstance(String param1, String param2) {
        RadioFragment fragment = new RadioFragment();
        Bundle args = new Bundle();
        args.putString(ARG_PARAM1, param1);
        args.putString(ARG_PARAM2, param2);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            mParam1 = getArguments().getString(ARG_PARAM1);
            mParam2 = getArguments().getString(ARG_PARAM2);
        }
    }
    private FragmentRadioBinding binding;
    private static final String TAG = "RadioFragment";
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        getActivity().setTitle("Radio Button");
        binding=FragmentRadioBinding.inflate(inflater, container, false);
        return binding.getRoot();
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        binding.etNumberOne.addTextChangedListener(this);
        binding.etNumberTwo.addTextChangedListener(this);

        binding.rgOperation.setOnCheckedChangeListener(this);
    }

    @Override
    public void beforeTextChanged(CharSequence s, int start, int count, int after) {
        Log.i(TAG, "Before Text Changed");
    }

    @Override
    public void onTextChanged(CharSequence s, int start, int before, int count) {
        Log.i(TAG, "On Text Changed");
        int checkedId=binding.rgOperation.getCheckedRadioButtonId();
        calculate(checkedId);
    }

    private void calculate(int checkedId) {


        int no1=0, no2=0, sum=0;
        try {
            String numberOne = binding.etNumberOne.getText().toString();
            if(!numberOne.equals("")){
                no1 = Integer.parseInt(numberOne);
            }
            String numberTwo = binding.etNumberTwo.getText().toString();
            if(!numberTwo.equals("")){
                no2 = Integer.parseInt(numberTwo);
            }
            //

            switch (checkedId){
                case R.id.rbAddition:
                    sum = no1 + no2;
                    break;
                case R.id.rbSubstraction:
                    sum = no1 - no2;
                    break;
                case R.id.rbDivision:
                    sum = no1 / no2;
                    break;
                case R.id.rbMultiply:
                    sum = no1 * no2;
                    break;
            }

            binding.tvResult.setText("Result : " + sum);
        }catch (Exception ex){
            Log.i(TAG, ex.toString());
            binding.tvResult.setText("Result : " + sum);
        }
    }

    @Override
    public void afterTextChanged(Editable s) {
        Log.i(TAG, "After Text Changed");
    }



    @Override
    public void onCheckedChanged(RadioGroup group, int checkedId) {
        calculate(checkedId);
    }
}