package com.example.feb22storage;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Log;
import android.widget.Toast;

import com.example.feb22storage.databinding.ActivityMainBinding;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;

public class MainActivity extends AppCompatActivity {
    private static final String MSG = "msg";
    private static final String SCORE = "score";
    private ActivityMainBinding binding;
    private static final String TAG = "MainActivity";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding=ActivityMainBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        binding.btnWriteMessage.setOnClickListener(v->{
            String message=binding.etMessage.getText().toString();
            try {
                FileOutputStream fos=openFileOutput(getString(R.string.app_name),MODE_PRIVATE);
                fos.write(message.getBytes());
                fos.close();
                Toast.makeText(this, "File Written Success!!!", Toast.LENGTH_SHORT).show();
            } catch (Exception e) {
                e.printStackTrace();
            }
        });


        binding.btnReadMessage.setOnClickListener(v->{
            try{
                FileInputStream fis=openFileInput(getString(R.string.app_name));
                byte b[]=new byte[fis.available()];
                fis.read(b);
                fis.close();
                String msg=new String(b);
                binding.etMessage.setText(msg);
            }catch (Exception e){
                e.printStackTrace();
            }
        });


        binding.btnWritePreference.setOnClickListener(v->{
            SharedPreferences sharedPrefs=getSharedPreferences(getString(R.string.app_name), MODE_PRIVATE);
            SharedPreferences.Editor editor=sharedPrefs.edit();

            String msg=binding.etMessage.getText().toString();
            editor.putString(MSG,msg);
            editor.putInt(SCORE,700);

            editor.commit();
            Toast.makeText(this, "Shared Preference written!!!", Toast.LENGTH_SHORT).show();

        });

        binding.btnReadPreference.setOnClickListener(v->{
            SharedPreferences sharedPrefs=getSharedPreferences(getString(R.string.app_name), MODE_PRIVATE);

            String msg=sharedPrefs.getString(MSG,null);
            int score=sharedPrefs.getInt(SCORE,0);

            binding.etMessage.setText(msg);
            Log.i(TAG, "Score : "+score);
        });

        binding.btnLogout.setOnClickListener(v->{
            SharedPreferences sharedPrefs=getSharedPreferences(getString(R.string.app_name), MODE_PRIVATE);
            SharedPreferences.Editor editor=sharedPrefs.edit();
            editor.clear();
            editor.commit();

            Intent intent=new Intent(this, LoginActivity.class);
            startActivity(intent);
            finish();
        });
    }
}