package com.example.feb22storage.sqlite.adapter;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.feb22storage.databinding.UserRowItemBinding;
import com.example.feb22storage.sqlite.entities.User;

import java.util.List;

public class UserAdapter extends RecyclerView.Adapter<UserAdapter.UserViewHolder> {

    private List<User> list;

    public void setList(List<User> list) {
        this.list = list;
    }

    @NonNull
    @Override
    public UserViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        LayoutInflater inflater=LayoutInflater.from(parent.getContext());
        UserRowItemBinding binding=UserRowItemBinding.inflate(inflater, parent, false);
        UserViewHolder viewHolder=new UserViewHolder(binding);
        return viewHolder;
    }

    @Override
    public void onBindViewHolder(@NonNull UserViewHolder holder, int position) {
        User theUser=list.get(position);
        holder.binding.setUser(theUser);
    }

    @Override
    public int getItemCount() {
        return list.size();
    }

    public class UserViewHolder extends RecyclerView.ViewHolder {
        private UserRowItemBinding binding;
        public UserViewHolder(@NonNull UserRowItemBinding binding) {
            super(binding.getRoot());
            this.binding=binding;
        }
    }
}
