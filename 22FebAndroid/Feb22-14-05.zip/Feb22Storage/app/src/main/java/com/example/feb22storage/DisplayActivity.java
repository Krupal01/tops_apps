package com.example.feb22storage;

import androidx.appcompat.app.AppCompatActivity;
import androidx.databinding.DataBindingUtil;

import android.content.Intent;
import android.os.Bundle;

import com.example.feb22storage.databinding.ActivityDisplayBinding;

public class DisplayActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        ActivityDisplayBinding binding= DataBindingUtil.setContentView(this, R.layout.activity_display);
        
        //setContentView(R.layout.activity_display);

        Intent intent=getIntent();
        Person person=intent.getParcelableExtra("person");

        binding.setPerson(person);

    }
}