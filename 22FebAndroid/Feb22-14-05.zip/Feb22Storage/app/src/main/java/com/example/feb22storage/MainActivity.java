package com.example.feb22storage;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;

import com.example.feb22storage.databinding.ActivityMainBinding;

public class MainActivity extends AppCompatActivity {
    private ActivityMainBinding binding;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding=ActivityMainBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        binding.btnSubmit.setOnClickListener(v->{
            String firstName=binding.etFirstName.getText().toString();
            String lastName=binding.etLastName.getText().toString();
            String email=binding.etEmail.getText().toString();

            Person person=new Person(firstName, lastName, email);
            Intent intent=new Intent(this, DisplayActivity.class);
            intent.putExtra("person",person);
            startActivity(intent);
        });
    }
}