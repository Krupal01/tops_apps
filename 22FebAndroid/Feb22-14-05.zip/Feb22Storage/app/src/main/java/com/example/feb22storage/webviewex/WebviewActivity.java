package com.example.feb22storage.webviewex;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import com.example.feb22storage.databinding.ActivityWebvieBinding;

public class WebviewActivity extends AppCompatActivity {
    private ActivityWebvieBinding binding;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding=ActivityWebvieBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        binding.webview.loadUrl("file:///android_asset/index.html");
        binding.webview.getSettings().setJavaScriptEnabled(true);

        binding.webview.addJavascriptInterface(new WebAppInterface(this), "Android");

    }
}