package com.example.feb22storage.sqlite;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;

import android.os.Bundle;

import com.example.feb22storage.R;
import com.example.feb22storage.databinding.ActivityUserListBinding;
import com.example.feb22storage.sqlite.adapter.UserAdapter;
import com.example.feb22storage.sqlite.dao.UserDao;
import com.example.feb22storage.sqlite.entities.User;

import java.util.List;

public class UserListActivity extends AppCompatActivity {

    private ActivityUserListBinding binding;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding=ActivityUserListBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        AppDatabase db=UtilityHelper.getDataBase(this);
        UserDao dao=db.userDao();

        List<User> list = dao.getUsers();
        binding.recyclerView.setLayoutManager(new LinearLayoutManager(this));
        UserAdapter adapter=new UserAdapter();
        adapter.setList(list);
        binding.recyclerView.setAdapter(adapter);

    }
}