package com.example.feb22storage.sqlite;

import android.content.Context;

import androidx.room.Room;

import com.example.feb22storage.R;

public class UtilityHelper {

    public static AppDatabase getDataBase(Context context){
        AppDatabase db= Room.databaseBuilder(context,
                AppDatabase.class, context.getString(R.string.app_name))
                .allowMainThreadQueries()
                .build();
        return db;
    }
}
