package com.example.feb22storage;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.widget.EditText;

import com.example.feb22storage.databinding.ActivityLoginBinding;

public class LoginActivity extends AppCompatActivity {
    private ActivityLoginBinding binding;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        binding=ActivityLoginBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        checkUserLoggedIn();

        binding.btnLogin.setOnClickListener(v->{
            // validate the user
            String username=binding.etUsername.getText().toString();
            String password=binding.etPassword.getText().toString();

            if(username.equals("admin") && password.equals("123456")){

                SharedPreferences sharedPreferences=getSharedPreferences(getString(R.string.app_name), MODE_PRIVATE);
                SharedPreferences.Editor editor=sharedPreferences.edit();
                editor.putString("username",username);
                editor.putBoolean("isLogin",true);
                editor.commit();

                Intent intent=new Intent(this, MainActivity.class);
                startActivity(intent);
                finish();
            }
        });
    }

    private void checkUserLoggedIn() {
        SharedPreferences sharedPreferences=getSharedPreferences(getString(R.string.app_name), MODE_PRIVATE);
        boolean isLogin=sharedPreferences.getBoolean("isLogin", false);
        if(isLogin){
            Intent intent=new Intent(this, MainActivity.class);
            startActivity(intent);
            finish();
        }
    }
}