package com.example.feb22storage.sqlite.dao;

import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.Query;
import androidx.room.Update;

import com.example.feb22storage.sqlite.entities.User;

import java.util.List;

@Dao
public interface UserDao {

    @Insert
    void saveUser(User user);

    @Update
    void updateUser(User user);

    @Delete
    void deleteUser(User user);

    @Query("Select * from User")
    List<User> getUsers();

}
