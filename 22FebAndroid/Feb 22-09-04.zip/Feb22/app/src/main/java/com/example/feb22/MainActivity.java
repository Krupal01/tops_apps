package com.example.feb22;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.EditText;

public class MainActivity extends AppCompatActivity {

    private static final String TAG = "MainActivity";
    private EditText etMessage;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        etMessage=findViewById(R.id.etMessage);

        Log.i(TAG,"onCreate");
    }

    public void submitForm(View view){
        Log.i(TAG,"Submit Form");
        String msg=etMessage.getText().toString();
        Log.i(TAG, msg);

        // launch Second Activity
        Context context=this;
        //Context context=getApplicationContext();
        //Context context=MainActivity.this;

        Intent intent=new Intent(context, SecondActivity.class);
        // pass data to SecondActivity
        intent.putExtra("msg",msg);
        startActivity(intent);
    }

    @Override
    protected void onStart() {
        super.onStart();
        Log.i(TAG,"onStart");
    }

    @Override
    protected void onResume() {
        super.onResume();
        Log.i(TAG,"onResume");
    }

    @Override
    protected void onStop() {
        super.onStop();
        Log.i(TAG,"onStop");
    }

    @Override
    protected void onPause() {
        super.onPause();
        Log.i(TAG,"onPause");
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        Log.i(TAG,"onDestroy");
    }
}