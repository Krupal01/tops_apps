package com.example.feb22.fragments;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import com.example.feb22.R;

public class FragmentHostActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_fragment_host);
    }
}