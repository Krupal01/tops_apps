package com.example.feb22firebase.animation;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import com.example.feb22firebase.R;

public class lottiActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_lotti);
    }
}