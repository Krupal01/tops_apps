package com.example.feb22firebase.animation;

import androidx.appcompat.app.AppCompatActivity;

import android.graphics.drawable.AnimationDrawable;
import android.os.Bundle;

import com.example.feb22firebase.R;
import com.example.feb22firebase.databinding.ActivityFrameBinding;

public class FrameActivity extends AppCompatActivity {
    private ActivityFrameBinding binding;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding=ActivityFrameBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        binding.imageView.setBackgroundResource(R.drawable.frame);
        AnimationDrawable animationDrawable= (AnimationDrawable) binding.imageView.getBackground();
        animationDrawable.start();

    }
}