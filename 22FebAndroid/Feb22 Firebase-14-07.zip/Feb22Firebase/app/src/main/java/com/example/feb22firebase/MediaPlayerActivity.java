package com.example.feb22firebase;

import androidx.appcompat.app.AppCompatActivity;

import android.media.MediaPlayer;
import android.os.Bundle;
import android.os.Handler;
import android.widget.SeekBar;

import com.example.feb22firebase.databinding.ActivityMediaPlayerBinding;

public class MediaPlayerActivity extends AppCompatActivity implements SeekBar.OnSeekBarChangeListener, MediaPlayer.OnCompletionListener {
    private static final long ONE_SECOND = 1000;
    private ActivityMediaPlayerBinding binding;
    private MediaPlayer mMediaPlayer;
    private Handler mHandler=new Handler();

    private String songUrl="https://file-examples-com.github.io/uploads/2017/11/file_example_MP3_700KB.mp3";

    Runnable runnable=new Runnable() {
        @Override
        public void run() {
            int duration=mMediaPlayer.getDuration();   // in millisecond
            binding.tvTotalDuration.setText(getTimeFromMillis(duration));

            int currentPosition=mMediaPlayer.getCurrentPosition();
            binding.tvCurrentPosition.setText(getTimeFromMillis(currentPosition));

            // reschedule handler after 1 second
            mHandler.postDelayed(this, ONE_SECOND);

            int progress = (currentPosition*100)/duration;
            binding.songProgress.setProgress(progress);
        }
    };
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding=ActivityMediaPlayerBinding.inflate(getLayoutInflater());

        setContentView(binding.getRoot());



        binding.imagePlay.setOnClickListener(v->{
            if(mMediaPlayer==null) {
                // when click first time
                mMediaPlayer = MediaPlayer.create(this, R.raw.song);
                mMediaPlayer.start();
                binding.imagePlay.setImageResource(android.R.drawable.ic_media_pause);
                mHandler.postDelayed(runnable, ONE_SECOND);
                mMediaPlayer.setOnCompletionListener(this);
            }else{
                // when click 2,3,4,5,... times
                if(mMediaPlayer.isPlaying()){
                    // pause the song
                    mMediaPlayer.pause();
                    // icon play
                    binding.imagePlay.setImageResource(android.R.drawable.ic_media_play);
                }else{
                    // play the song
                    mMediaPlayer.start();
                    // icon pause
                    binding.imagePlay.setImageResource(android.R.drawable.ic_media_pause);
                }
            }
        });

        binding.songProgress.setOnSeekBarChangeListener(this);

    }

    private String getTimeFromMillis(int duration) {
        int hour=duration/(60*60*1000);
        int min=(duration%(60*60*1000))/(60*1000);
        int sec=((duration%(60*60*1000))%(60*1000))/1000;
        return hour+":"+min+":"+sec;
    }

    @Override
    public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
        if(mMediaPlayer!=null && fromUser){
            // progress = percentage
            int duration=mMediaPlayer.getDuration();
            int currentPosition = (progress*duration)/100;
            mMediaPlayer.seekTo(currentPosition);
        }
    }

    @Override
    public void onStartTrackingTouch(SeekBar seekBar) {

    }

    @Override
    public void onStopTrackingTouch(SeekBar seekBar) {

    }

    @Override
    public void onCompletion(MediaPlayer mp) {
        mMediaPlayer.release();
        mMediaPlayer=null;
        
        mMediaPlayer = MediaPlayer.create(this, R.raw.song2);
        mMediaPlayer.start();
        binding.imagePlay.setImageResource(android.R.drawable.ic_media_pause);
        mHandler.postDelayed(runnable, ONE_SECOND);
        mMediaPlayer.setOnCompletionListener(this);
    }
}