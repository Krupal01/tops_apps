package com.example.feb22firebase.model;

import com.google.gson.annotations.SerializedName;

public class Item{

	@SerializedName("snippet")
	private String snippet;

	@SerializedName("lng")
	private double lng;

	@SerializedName("title")
	private String title;

	@SerializedName("lat")
	private double lat;

	public String getSnippet(){
		return snippet;
	}

	public double getLng(){
		return lng;
	}

	public String getTitle(){
		return title;
	}

	public double getLat(){
		return lat;
	}
}