package com.example.feb22firebase;

import androidx.appcompat.app.AppCompatActivity;

import android.content.ContentResolver;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import android.provider.ContactsContract;
import android.util.Log;

public class ReadContactsActivity extends AppCompatActivity {
    private static final String TAG = "ReadContactsActivity";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_read_contacts);

        getAllContacts();
    }

    private void getAllContacts() {

        // getRawContactsIdList
        ContentResolver resolver=getContentResolver();
        // Row contacts content uri( access raw_contacts table. ).
        Uri rawContactUri = ContactsContract.RawContacts.CONTENT_URI;
        // Return _id column in contacts raw_contacts table.
        String queryColumnArr[] = {ContactsContract.RawContacts._ID};

        Cursor cursor=resolver.query(rawContactUri, queryColumnArr, null,null,null);

        if(cursor!=null){
            cursor.moveToFirst();
            do{
               int rawContactsId=cursor.getInt(cursor.getColumnIndex(ContactsContract.RawContacts._ID));
                Log.i(TAG, rawContactsId+"");
                // Data content uri (access data table. )
                Uri dataContentUri = ContactsContract.Data.CONTENT_URI;
                String selection=ContactsContract.Data.RAW_CONTACT_ID+"="+rawContactsId;
                Cursor dataCursor=resolver.query(dataContentUri,null,selection, null,null);

                if(dataCursor!=null){
                    dataCursor.moveToFirst();
                    do {
                        String mimeType = dataCursor.getString(dataCursor.getColumnIndex(ContactsContract.Data.MIMETYPE));
                        Log.i(TAG, mimeType);


                        switch (mimeType)
                        {
                            // Get email data.
                            case ContactsContract.CommonDataKinds.Email.CONTENT_ITEM_TYPE :
                                // Email.ADDRESS == data1
                                String emailAddress = dataCursor.getString(dataCursor.getColumnIndex(ContactsContract.CommonDataKinds.Email.ADDRESS));
                                // Email.TYPE == data2
                                int emailType = dataCursor.getInt(dataCursor.getColumnIndex(ContactsContract.CommonDataKinds.Email.TYPE));

                                //String emailTypeStr = getEmailTypeString(emailType);

                                Log.i(TAG, "Email Address : " + emailAddress);
                                Log.i(TAG, "Email Int Type : " + emailType);
                                //Log.i(TAG, "Email String Type : " + emailTypeStr);
                                break;

                            // Get im data.
                            case ContactsContract.CommonDataKinds.Im.CONTENT_ITEM_TYPE:
                                // Im.PROTOCOL == data5
                                String imProtocol = dataCursor.getString(dataCursor.getColumnIndex(ContactsContract.CommonDataKinds.Im.PROTOCOL));
                                // Im.DATA == data1
                                String imId = dataCursor.getString(dataCursor.getColumnIndex(ContactsContract.CommonDataKinds.Im.DATA));

                                //ret.add("IM Protocol : " + imProtocol);
                                //ret.add("IM ID : " + imId);
                                break;

                            // Get nickname
                            case ContactsContract.CommonDataKinds.Nickname.CONTENT_ITEM_TYPE:
                                // Nickname.NAME == data1
                                String nickName = dataCursor.getString(dataCursor.getColumnIndex(ContactsContract.CommonDataKinds.Nickname.NAME));
                                //ret.add("Nick name : " + nickName);
                                break;

                            // Get organization data.
                            case ContactsContract.CommonDataKinds.Organization.CONTENT_ITEM_TYPE:
                                // Organization.COMPANY == data1
                                String company = dataCursor.getString(dataCursor.getColumnIndex(ContactsContract.CommonDataKinds.Organization.COMPANY));
                                // Organization.DEPARTMENT == data5
                                String department = dataCursor.getString(dataCursor.getColumnIndex(ContactsContract.CommonDataKinds.Organization.DEPARTMENT));
                                // Organization.TITLE == data4
                                String title = dataCursor.getString(dataCursor.getColumnIndex(ContactsContract.CommonDataKinds.Organization.TITLE));
                                // Organization.JOB_DESCRIPTION == data6
                                String jobDescription = dataCursor.getString(dataCursor.getColumnIndex(ContactsContract.CommonDataKinds.Organization.JOB_DESCRIPTION));
                                // Organization.OFFICE_LOCATION == data9
                                String officeLocation = dataCursor.getString(dataCursor.getColumnIndex(ContactsContract.CommonDataKinds.Organization.OFFICE_LOCATION));

//                                ret.add("Company : " + company);
//                                ret.add("department : " + department);
//                                ret.add("Title : " + title);
//                                ret.add("Job Description : " + jobDescription);
//                                ret.add("Office Location : " + officeLocation);
                                break;

                            // Get phone number.
                            case ContactsContract.CommonDataKinds.Phone.CONTENT_ITEM_TYPE:
                                // Phone.NUMBER == data1
                                String phoneNumber = dataCursor.getString(dataCursor.getColumnIndex(ContactsContract.CommonDataKinds.Phone.NUMBER));
                                // Phone.TYPE == data2
                                int phoneTypeInt = dataCursor.getInt(dataCursor.getColumnIndex(ContactsContract.CommonDataKinds.Phone.TYPE));
                                //String phoneTypeStr = getPhoneTypeString(phoneTypeInt);

                                Log.i(TAG, "Phone Number : " + phoneNumber);
                                Log.i(TAG, "Phone Type Integer : " + phoneTypeInt);
                                //ret.add("Phone Type String : " + phoneTypeStr);
                                break;

                            // Get sip address.
                            case ContactsContract.CommonDataKinds.SipAddress.CONTENT_ITEM_TYPE:
                                // SipAddress.SIP_ADDRESS == data1
                                String address = dataCursor.getString(dataCursor.getColumnIndex(ContactsContract.CommonDataKinds.SipAddress.SIP_ADDRESS));
                                // SipAddress.TYPE == data2
                                int addressTypeInt = dataCursor.getInt(dataCursor.getColumnIndex(ContactsContract.CommonDataKinds.SipAddress.TYPE));
                               // String addressTypeStr = getEmailTypeString(addressTypeInt);

//                                ret.add("Address : " + address);
//                                ret.add("Address Type Integer : " + addressTypeInt);
//                                ret.add("Address Type String : " + addressTypeStr);
                                break;

                            // Get display name.
                            case ContactsContract.CommonDataKinds.StructuredName.CONTENT_ITEM_TYPE:
                                // StructuredName.DISPLAY_NAME == data1
                                String displayName = dataCursor.getString(dataCursor.getColumnIndex(ContactsContract.CommonDataKinds.StructuredName.DISPLAY_NAME));
                                // StructuredName.GIVEN_NAME == data2
                                String givenName = dataCursor.getString(dataCursor.getColumnIndex(ContactsContract.CommonDataKinds.StructuredName.GIVEN_NAME));
                                // StructuredName.FAMILY_NAME == data3
                                String familyName = dataCursor.getString(dataCursor.getColumnIndex(ContactsContract.CommonDataKinds.StructuredName.FAMILY_NAME));

                                Log.i(TAG, "Display Name : " + displayName);
                                Log.i(TAG, "Given Name : " + givenName);
//                                ret.add("Family Name : " + familyName);
                                break;

                            // Get postal address.
                            case ContactsContract.CommonDataKinds.StructuredPostal.CONTENT_ITEM_TYPE:
                                // StructuredPostal.COUNTRY == data10
                                String country = dataCursor.getString(dataCursor.getColumnIndex(ContactsContract.CommonDataKinds.StructuredPostal.COUNTRY));
                                // StructuredPostal.CITY == data7
                                String city = dataCursor.getString(dataCursor.getColumnIndex(ContactsContract.CommonDataKinds.StructuredPostal.CITY));
                                // StructuredPostal.REGION == data8
                                String region = dataCursor.getString(dataCursor.getColumnIndex(ContactsContract.CommonDataKinds.StructuredPostal.REGION));
                                // StructuredPostal.STREET == data4
                                String street = dataCursor.getString(dataCursor.getColumnIndex(ContactsContract.CommonDataKinds.StructuredPostal.STREET));
                                // StructuredPostal.POSTCODE == data9
                                String postcode = dataCursor.getString(dataCursor.getColumnIndex(ContactsContract.CommonDataKinds.StructuredPostal.POSTCODE));
                                // StructuredPostal.TYPE == data2
                                int postType = dataCursor.getInt(dataCursor.getColumnIndex(ContactsContract.CommonDataKinds.StructuredPostal.TYPE));
//                                String postTypeStr = getEmailTypeString(postType);

//                                ret.add("Country : " + country);
//                                ret.add("City : " + city);
//                                ret.add("Region : " + region);
//                                ret.add("Street : " + street);
//                                ret.add("Postcode : " + postcode);
//                                ret.add("Post Type Integer : " + postType);
//                                ret.add("Post Type String : " + postTypeStr);
                                break;

                            // Get identity.
                            case ContactsContract.CommonDataKinds.Identity.CONTENT_ITEM_TYPE:
                                // Identity.IDENTITY == data1
                                String identity = dataCursor.getString(dataCursor.getColumnIndex(ContactsContract.CommonDataKinds.Identity.IDENTITY));
                                // Identity.NAMESPACE == data2
                                String namespace = dataCursor.getString(dataCursor.getColumnIndex(ContactsContract.CommonDataKinds.Identity.NAMESPACE));

//                                ret.add("Identity : " + identity);
//                                ret.add("Identity Namespace : " + namespace);
                                break;

                            // Get photo.
                            case ContactsContract.CommonDataKinds.Photo.CONTENT_ITEM_TYPE:
                                // Photo.PHOTO == data15
                                String photo = dataCursor.getString(dataCursor.getColumnIndex(ContactsContract.CommonDataKinds.Photo.PHOTO));
                                // Photo.PHOTO_FILE_ID == data14
                                String photoFileId = dataCursor.getString(dataCursor.getColumnIndex(ContactsContract.CommonDataKinds.Photo.PHOTO_FILE_ID));

//                                ret.add("Photo : " + photo);
//                                ret.add("Photo File Id: " + photoFileId);
                                break;

                            // Get group membership.
                            case ContactsContract.CommonDataKinds.GroupMembership.CONTENT_ITEM_TYPE:
                                // GroupMembership.GROUP_ROW_ID == data1
                                int groupId = dataCursor.getInt(dataCursor.getColumnIndex(ContactsContract.CommonDataKinds.GroupMembership.GROUP_ROW_ID));
//                                ret.add("Group ID : " + groupId);
                                break;

                            // Get website.
                            case ContactsContract.CommonDataKinds.Website.CONTENT_ITEM_TYPE:
                                // Website.URL == data1
                                String websiteUrl = dataCursor.getString(dataCursor.getColumnIndex(ContactsContract.CommonDataKinds.Website.URL));
                                // Website.TYPE == data2
                                int websiteTypeInt = dataCursor.getInt(dataCursor.getColumnIndex(ContactsContract.CommonDataKinds.Website.TYPE));
//                                String websiteTypeStr = getEmailTypeString(websiteTypeInt);
//
//                                ret.add("Website Url : " + websiteUrl);
//                                ret.add("Website Type Integer : " + websiteTypeInt);
//                                ret.add("Website Type String : " + websiteTypeStr);
                                break;

                            // Get note.
                            case ContactsContract.CommonDataKinds.Note.CONTENT_ITEM_TYPE:
                                // Note.NOTE == data1
                                String note = dataCursor.getString(dataCursor.getColumnIndex(ContactsContract.CommonDataKinds.Note.NOTE));
//                                ret.add("Note : " + note);
                                break;

                        }
                    }while(dataCursor.moveToNext());
                }
            }while(cursor.moveToNext());
        }
    }
}