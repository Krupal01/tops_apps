package com.example.feb22firebase;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Build;
import android.os.Bundle;
import android.speech.tts.TextToSpeech;

import com.example.feb22firebase.databinding.ActivityTextToSpeechBinding;

import java.util.Locale;

public class TextToSpeechActivity extends AppCompatActivity {
    private ActivityTextToSpeechBinding binding;
    private TextToSpeech tts;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding=ActivityTextToSpeechBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());


        tts=new TextToSpeech(this, new TextToSpeech.OnInitListener() {
            @Override
            public void onInit(int status) {
                if(status==TextToSpeech.SUCCESS){
                    tts.setLanguage(Locale.ENGLISH);
                    tts.setSpeechRate(0.5f);
                    tts.setPitch(0.5f);
                }
            }
        });

        binding.btnSpeak.setOnClickListener(v->{
            String text=binding.etMessage.getText().toString();
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
                tts.speak(text,TextToSpeech.QUEUE_ADD,null,null);
            }else{
                tts.speak(text, TextToSpeech.QUEUE_ADD, null);
            }
        });
    }
}