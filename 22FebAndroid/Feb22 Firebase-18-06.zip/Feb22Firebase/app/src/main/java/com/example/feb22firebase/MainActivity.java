package com.example.feb22firebase;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.util.Log;

import com.example.feb22firebase.databinding.ActivityMainBinding;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;

public class MainActivity extends AppCompatActivity {

    private ActivityMainBinding binding;
    private static final String TAG = "MainActivity";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding=ActivityMainBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        binding.btnSubmit.setOnClickListener(v->{
            String msg=binding.etMessage.getText().toString();

            FirebaseDatabase database=FirebaseDatabase.getInstance();
            DatabaseReference ref = database.getReference("persons").push();
            //ref.setValue(msg);

            Person thePerson=new Person("Test","test","test@gmail.com");
            ref.setValue(thePerson);
        });

        readValue();

        binding.btnDelete.setOnClickListener(v->{
            deletePerson();
        });
    }

    private void readValue() {
        FirebaseDatabase database=FirebaseDatabase.getInstance();
        //DatabaseReference ref = database.getReference("message");
        DatabaseReference ref = database.getReference("persons");
        ref.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull  DataSnapshot snapshot) {
                //String msg=snapshot.getValue(String.class);

//                Person thePerson=snapshot.getValue(Person.class);
//                if(thePerson!=null) {
//                    binding.tvMessage.setText(thePerson.toString());
//                }

                ArrayList<HashMap<String, Person>> personList=new ArrayList<>();
                Iterator<DataSnapshot> it = snapshot.getChildren().iterator();
                while(it.hasNext()){
                    DataSnapshot childSnapShot = it.next();
                    String key=childSnapShot.getKey();
                    Person thePerson=childSnapShot.getValue(Person.class);
                    HashMap<String, Person> hm=new HashMap<>();
                    hm.put(key, thePerson);
                    personList.add(hm);
                }
                binding.tvMessage.setText(personList.toString());
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                Log.i(TAG, "Failed. "+error);
            }
        });
    }

    public void deletePerson(){
        String key="-McIEj8SUHJKUjfuBn1R";
        FirebaseDatabase database=FirebaseDatabase.getInstance();
        DatabaseReference ref = database.getReference("persons").child(key);
        ref.removeValue();
    }

    public void updatePerson(){
        String key="-McIEj8SUHJKUjfuBn1R";
        FirebaseDatabase database=FirebaseDatabase.getInstance();
        DatabaseReference ref = database.getReference("persons").child(key);
        Person thePerson=new Person("Testing","testing","testing@gmail.com");
        ref.setValue(thePerson);
    }
}