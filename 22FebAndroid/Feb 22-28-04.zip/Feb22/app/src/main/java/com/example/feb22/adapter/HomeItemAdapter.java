package com.example.feb22.adapter;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.feb22.model.HomeItem;

import java.util.ArrayList;

public class HomeItemAdapter extends RecyclerView.Adapter<HomeItemAdapter.HomeViewHolder> {

    private ArrayList<HomeItem> items;

    // Click Event Step 1
    public interface HomeItemClickListener {
        void onHomeItemClick(HomeItem item);
    }

    // Click Event Step 2
    private HomeItemClickListener listener;

    // Click Event Step 3
    public HomeItemAdapter(HomeItemClickListener listener){
        this.listener=listener;
    }

    public void setItems(ArrayList<HomeItem> items) {
        this.items = items;
    }

    @NonNull
    @Override
    public HomeViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        LayoutInflater inflater=LayoutInflater.from(parent.getContext());
        View view=inflater.inflate(android.R.layout.simple_list_item_1,parent,false);
        HomeViewHolder viewHolder=new HomeViewHolder(view);
        return viewHolder;
    }

    @Override
    public void onBindViewHolder(@NonNull HomeViewHolder holder, int position) {
        HomeItem item=items.get(position);
        holder.tvTitle.setText(item.getTitle());

        // click event step 4
        holder.itemView.setOnClickListener(v->{
                listener.onHomeItemClick(item);
        });
    }

    @Override
    public int getItemCount() {
        return items.size();
    }

    public class HomeViewHolder extends RecyclerView.ViewHolder {
        private TextView tvTitle;
        public HomeViewHolder(@NonNull View itemView) {
            super(itemView);
            tvTitle=itemView.findViewById(android.R.id.text1);
        }
    }
}
