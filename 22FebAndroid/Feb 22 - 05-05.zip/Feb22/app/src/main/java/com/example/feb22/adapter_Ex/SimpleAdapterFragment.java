package com.example.feb22.adapter_Ex;

import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.SimpleAdapter;

import com.example.feb22.R;
import com.example.feb22.databinding.FragmentSimpleAdapterBinding;

import java.util.ArrayList;
import java.util.HashMap;

/**
 * A simple {@link Fragment} subclass.
 * Use the {@link SimpleAdapterFragment#newInstance} factory method to
 * create an instance of this fragment.
 */
public class SimpleAdapterFragment extends Fragment {

    // TODO: Rename parameter arguments, choose names that match
    // the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
    private static final String ARG_PARAM1 = "param1";
    private static final String ARG_PARAM2 = "param2";
    private static final String COUNTRY = "country";
    private static final String CAPITAL = "capital";

    // TODO: Rename and change types of parameters
    private String mParam1;
    private String mParam2;

    public SimpleAdapterFragment() {
        // Required empty public constructor
    }

    /**
     * Use this factory method to create a new instance of
     * this fragment using the provided parameters.
     *
     * @param param1 Parameter 1.
     * @param param2 Parameter 2.
     * @return A new instance of fragment SimpleAdapterFragment.
     */
    // TODO: Rename and change types and number of parameters
    public static SimpleAdapterFragment newInstance(String param1, String param2) {
        SimpleAdapterFragment fragment = new SimpleAdapterFragment();
        Bundle args = new Bundle();
        args.putString(ARG_PARAM1, param1);
        args.putString(ARG_PARAM2, param2);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            mParam1 = getArguments().getString(ARG_PARAM1);
            mParam2 = getArguments().getString(ARG_PARAM2);
        }
    }
    private FragmentSimpleAdapterBinding binding;
    private static final String TAG = "SimpleAdapterFragment";
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        binding=FragmentSimpleAdapterBinding.inflate(inflater,container,false);
        return binding.getRoot();
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        ArrayList<HashMap<String, String>> data=new ArrayList<>();
        HashMap<String, String> hashMap=new HashMap<>();
        hashMap.put(COUNTRY,"India");
        hashMap.put(CAPITAL,"Delhi");
        data.add(hashMap);

        hashMap=new HashMap<>();
        hashMap.put(COUNTRY,"Country One");
        hashMap.put(CAPITAL,"Capital One");
        data.add(hashMap);

        hashMap=new HashMap<>();
        hashMap.put(COUNTRY,"Country Two");
        hashMap.put(CAPITAL,"Capital Two");
        data.add(hashMap);


        String[] from={COUNTRY,CAPITAL};
        //int[] to={android.R.id.text1, android.R.id.text2};

        int[] to={R.id.tvCountry, R.id.tvCapital};

        // layout in inbuilt
        //SimpleAdapter adapter=new SimpleAdapter(getContext(),data, android.R.layout.simple_list_item_2,from,to);

        SimpleAdapter adapter=new SimpleAdapter(getContext(),data, R.layout.country_layout,from,to);

        /*binding.spCountry.setAdapter(adapter);

        binding.spCountry.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                HashMap<String, String> hm = data.get(position);
                String country=hm.get(COUNTRY);
                String capital=hm.get(CAPITAL);
                Log.i(TAG, country);
                Log.i(TAG, capital);
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });*/

        binding.listView.setAdapter(adapter);
    }
}