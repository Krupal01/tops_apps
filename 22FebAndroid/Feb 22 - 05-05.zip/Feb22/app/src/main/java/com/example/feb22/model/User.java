package com.example.feb22.model;

import android.util.Log;
import android.widget.ImageView;

import androidx.databinding.BindingAdapter;

import com.bumptech.glide.Glide;
import com.example.feb22.R;

public class User {
    private static final String TAG = "User";
    private String name, email;
    private int age;
    private boolean isOnline;
    private String imageUrl;

    public User(){

    }

    public User(String name, String email, int age, boolean isOnline, String imageUrl) {
        this.name = name;
        this.email = email;
        this.age = age;
        this.isOnline = isOnline;
        this.imageUrl=imageUrl;
    }

    public String getName() {
        return name;
    }

    public String getEmail() {
        return email;
    }

    public int getAge() {
        return age;
    }

    public boolean isOnline() {
        return isOnline;
    }

    public String getImageUrl() {
        return imageUrl;
    }

    public void handleClick(){
        Log.i(TAG,"Handle Click");
    }

    @BindingAdapter("android:imageUrl")
    public static void loadImage(ImageView view, String url){
        Glide.with(view)
                .load(url)
                .placeholder(R.drawable.loading)
                .error(R.drawable.error)
                .into(view);
    }
}
