package com.example.feb22;

import androidx.appcompat.app.AppCompatActivity;
import androidx.databinding.DataBindingUtil;
import androidx.databinding.ViewDataBinding;

import android.os.Bundle;

import com.example.feb22.databinding.ActivityDataBindingBinding;
import com.example.feb22.model.User;

public class DataBindingActivity extends AppCompatActivity {

    private ActivityDataBindingBinding binding;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        //setContentView(R.layout.activity_data_binding);
        binding=DataBindingUtil.setContentView(this,R.layout.activity_data_binding);
        binding.setMessage("Hello Data Binding");

        User user=new User("Paresh Raval","paresh@gmail.com",20,
                false,"https://homepages.cae.wisc.edu/~ece533/images/tulips.png");
        binding.setUser(user);
    }
}