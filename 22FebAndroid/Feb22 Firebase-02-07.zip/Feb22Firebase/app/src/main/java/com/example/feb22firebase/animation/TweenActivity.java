package com.example.feb22firebase.animation;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;

import com.example.feb22firebase.R;
import com.example.feb22firebase.databinding.ActivityTweenBinding;

public class TweenActivity extends AppCompatActivity {
    private ActivityTweenBinding binding;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding=ActivityTweenBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        Animation animation= AnimationUtils.loadAnimation(this,R.anim.scale);

        binding.btnStart.setOnClickListener(v->{

            binding.imageView.startAnimation(animation);

        });
    }
}