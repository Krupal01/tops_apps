package com.example.feb22firebase.receiver;

import androidx.appcompat.app.AppCompatActivity;

import android.content.BroadcastReceiver;
import android.content.Intent;
import android.content.IntentFilter;
import android.net.ConnectivityManager;
import android.os.Bundle;

import com.example.feb22firebase.R;
import com.example.feb22firebase.databinding.ActivityReceiverBinding;

public class ReceiverActivity extends AppCompatActivity {
    private ActivityReceiverBinding binding;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding=ActivityReceiverBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());


        BroadcastReceiver receiver=new MyReceiver(binding.etOtp);
        IntentFilter filter=new IntentFilter(ConnectivityManager.CONNECTIVITY_ACTION);
        filter.addAction(Intent.ACTION_AIRPLANE_MODE_CHANGED);
        filter.addAction(Intent.ACTION_BATTERY_LOW);
        filter.addAction("android.provider.Telephony.SMS_RECEIVED");
        registerReceiver(receiver,filter);
    }
}