package com.example.feb22online;

import androidx.appcompat.app.AppCompatActivity;

import android.app.Activity;
import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;

import com.example.feb22online.databinding.ActivityMainBinding;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;

public class MainActivity extends AppCompatActivity implements MyAsyncTask.OnTaskResponseListener {
    private static final String TAG = "MainActivity";
    private String requestUrl="https://jsonplaceholder.typicode.com/posts/1";
    private ActivityMainBinding binding;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding= ActivityMainBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        //fetchDataFromUrl(requestUrl);

        MyAsyncTask asyncTask=new MyAsyncTask();
        asyncTask.setRequestUrl(requestUrl);
        asyncTask.setListener(this);
        asyncTask.execute();
    }


    @Override
    public void onResponse(String response) {
        //binding.tvData.setText(response);
        try {
            JSONObject jsonObject=new JSONObject(response);
            int userId=jsonObject.getInt("userId");
            String title=jsonObject.getString("title");
            String body=jsonObject.getString("body");

            binding.tvData.setText(title+"\n\n\n"+body);
        } catch (JSONException e) {
            e.printStackTrace();
        }
    }
}