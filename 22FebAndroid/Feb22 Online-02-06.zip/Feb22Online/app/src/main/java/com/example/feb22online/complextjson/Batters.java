package com.example.feb22online.complextjson;

import java.util.List;
import com.google.gson.annotations.SerializedName;

public class Batters{

	@SerializedName("batter")
	private List<BatterItem> batter;

	public List<BatterItem> getBatter(){
		return batter;
	}
}