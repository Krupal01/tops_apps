package com.example.feb22online.jsonarrayparsing;

import androidx.appcompat.app.AppCompatActivity;

import android.app.ProgressDialog;
import android.os.Bundle;
import android.widget.ArrayAdapter;

import com.example.feb22online.MyAsyncTask;
import com.example.feb22online.databinding.ActivityPostsBinding;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;

public class PostsActivity extends AppCompatActivity implements MyAsyncTask.OnTaskResponseListener {
    String url="https://jsonplaceholder.typicode.com/posts/";
    private ActivityPostsBinding binding;
    private ProgressDialog pd;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding=ActivityPostsBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        pd=ProgressDialog.show(this,"Wait","Fetching Data!!!!");

        MyAsyncTask asyncTask=new MyAsyncTask();
        asyncTask.setRequestUrl(url);
        asyncTask.setListener(this);
        asyncTask.execute();
    }

    @Override
    public void onResponse(String response) {
        pd.dismiss();
        ArrayList<Post> postList=new ArrayList<>();
        try {
            JSONArray jsonArray=new JSONArray(response);
            for(int i=0;i<jsonArray.length();i++){
                JSONObject postJson=jsonArray.getJSONObject(i);
                int userId=postJson.getInt("userId");
                int id=postJson.getInt("id");
                String title=postJson.getString("title");
                String body=postJson.getString("body");
                Post thePost=new Post(id, userId, title, body);
                postList.add(thePost);
            }

            ArrayAdapter<Post> adapter=new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, postList);
            binding.listView.setAdapter(adapter);
        } catch (JSONException e) {
            e.printStackTrace();
        }
    }
}