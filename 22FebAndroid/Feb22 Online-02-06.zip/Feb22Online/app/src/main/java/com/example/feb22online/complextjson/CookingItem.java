package com.example.feb22online.complextjson;

import java.util.List;
import com.google.gson.annotations.SerializedName;

public class CookingItem{

	@SerializedName("ppu")
	private double ppu;

	@SerializedName("batters")
	private Batters batters;

	@SerializedName("name")
	private String name;

	@SerializedName("id")
	private String id;

	@SerializedName("type")
	private String type;

	@SerializedName("topping")
	private List<ToppingItem> topping;

	public double getPpu(){
		return ppu;
	}

	public Batters getBatters(){
		return batters;
	}

	public String getName(){
		return name;
	}

	public String getId(){
		return id;
	}

	public String getType(){
		return type;
	}

	public List<ToppingItem> getTopping(){
		return topping;
	}

	@Override
	public String toString() {
		return "CookingItem{" +
				"ppu=" + ppu +
				", batters=" + batters +
				", name='" + name + '\'' +
				", id='" + id + '\'' +
				", type='" + type + '\'' +
				", topping=" + topping +
				'}';
	}
}