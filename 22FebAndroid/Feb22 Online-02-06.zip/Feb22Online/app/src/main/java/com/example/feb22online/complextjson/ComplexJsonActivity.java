package com.example.feb22online.complextjson;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.util.Log;

import com.example.feb22online.R;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.lang.reflect.Type;
import java.util.ArrayList;

public class ComplexJsonActivity extends AppCompatActivity {
    private static final String TAG = "ComplexJsonActivity";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_complex_json);

        String data=readFileFromAssets();
        if(data!=null){
            // json parsing
            try {
                ArrayList<CookingItem> cookings=new ArrayList<>();
                Gson gson=new Gson();
                /*JSONArray jsonArray = new JSONArray(data);

                for (int i = 0; i < jsonArray.length(); i++) {
                    JSONObject jsonObject=jsonArray.getJSONObject(i);
                    // from json data to java object using gson
                    CookingItem theCooking=gson.fromJson(jsonObject.toString(),CookingItem.class);
                    cookings.add(theCooking);
                }*/
                Type type = new TypeToken<ArrayList<CookingItem>>() {}.getType();
                cookings=gson.fromJson(data, type);
                Log.i(TAG, cookings.toString());
            }catch (Exception ex){

            }
        }
    }

    private String readFileFromAssets() {
        BufferedReader reader = null;
        try {
            reader = new BufferedReader(
                    new InputStreamReader(getAssets().open("data.json")));

            // do reading, usually loop until end of file reading
            String mLine, data="";
            while ((mLine = reader.readLine()) != null) {
                //process line
                data+=mLine;
            }
            Log.i(TAG, data);
            return data;
        } catch (IOException e) {
            //log the exception
            Log.i(TAG, e.toString());
        } finally {
            if (reader != null) {
                try {
                    reader.close();
                } catch (IOException e) {
                    //log the exception
                }
            }
        }
        return null;
    }
}