package com.example.feb22online;

import android.os.AsyncTask;
import android.util.Log;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;

import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;

/*
    1. String => doInBackground() args
    2. Void => onProgressUpdate() args
    3. String =>  doInBackground() return type
     */
public  class MyAsyncTask extends AsyncTask<String, Void, String>
    {
        private static final String TAG = "MyAsyncTask";
        private String requestUrl;

        // create interface for jump back to calling place
        public interface OnTaskResponseListener {
            void onResponse(String response);
        }
        private OnTaskResponseListener listener;

        public void setRequestUrl(String requestUrl) {
            this.requestUrl = requestUrl;
        }

        public void setListener(OnTaskResponseListener listener) {
            this.listener = listener;
        }

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
        }

        @Override
        protected String doInBackground(String... strings) {
            // we can not use UI views in doinbackground
            //String response="";

            OkHttpClient client = new OkHttpClient();
            Request request=new Request.Builder()
                    .url(requestUrl)
                    .build();
            try {
                Response response=client.newCall(request).execute();
                return response.body().string();
            } catch (IOException e) {
                e.printStackTrace();
            }

            return null;
        }

        @Override
        protected void onPostExecute(String resp) {
            super.onPostExecute(resp);
            //binding.tvData.setText(resp);
            listener.onResponse(resp);
        }

        @Override
        protected void onProgressUpdate(Void... values) {
            super.onProgressUpdate(values);
        }
}

