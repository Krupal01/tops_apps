package com.example.feb22online.complextjson;

import com.google.gson.annotations.SerializedName;

public class BatterItem{

	@SerializedName("id")
	private String id;

	@SerializedName("type")
	private String type;

	public String getId(){
		return id;
	}

	public String getType(){
		return type;
	}
}