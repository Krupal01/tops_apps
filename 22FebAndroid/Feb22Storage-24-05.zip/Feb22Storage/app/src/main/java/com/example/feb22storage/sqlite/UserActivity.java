package com.example.feb22storage.sqlite;

import androidx.appcompat.app.AppCompatActivity;
import androidx.room.Room;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.widget.Toast;

import com.example.feb22storage.R;
import com.example.feb22storage.databinding.ActivityUserBinding;
import com.example.feb22storage.sqlite.dao.UserDao;
import com.example.feb22storage.sqlite.entities.User;

public class UserActivity extends AppCompatActivity {
    private ActivityUserBinding binding;
    private User theUser;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding= ActivityUserBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        Intent intent=getIntent();
        theUser=intent.getParcelableExtra("user");
        if(theUser!=null){
            // We are here for update operation
            binding.etId.setText(String.valueOf(theUser.id));
            binding.etFirstName.setText(theUser.firstName);
            binding.etLastName.setText(theUser.lastName);
            binding.etEmail.setText(theUser.email);
            binding.etId.setEnabled(false);
        }


        binding.btnSubmit.setOnClickListener(v->{

            AppDatabase db=UtilityHelper.getDataBase(this);
            UserDao dao=db.userDao();
            if(theUser==null) {
                theUser = new User();
                theUser.id = Integer.parseInt(binding.etId.getText().toString());
                theUser.firstName = binding.etFirstName.getText().toString();
                theUser.lastName = binding.etLastName.getText().toString();
                theUser.email = binding.etEmail.getText().toString();
                dao.saveUser(theUser);
                Toast.makeText(this, "User Saved!!!!", Toast.LENGTH_SHORT).show();
            }
            else{
                // update operation
                theUser.firstName = binding.etFirstName.getText().toString();
                theUser.lastName = binding.etLastName.getText().toString();
                theUser.email = binding.etEmail.getText().toString();
                dao.updateUser(theUser);
                Toast.makeText(this, "User Updated!!!!", Toast.LENGTH_SHORT).show();
            }


            //setResult(RESULT_OK);

            Intent theIntent=new Intent();
            theIntent.putExtra("user",theUser);
            setResult(RESULT_OK,theIntent);
            finish();
        });
    }
}