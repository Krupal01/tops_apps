package com.example.feb22storage;

import androidx.activity.result.ActivityResultCallback;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;

import android.Manifest;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.util.Log;
import android.view.View;
import android.widget.Toast;

import com.example.feb22storage.databinding.ActivityMainBinding;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;

public class MainActivity extends AppCompatActivity {
    private static final String MSG = "msg";
    private static final String SCORE = "score";
    private static final int REQ_WRITE_EXTERNAL = 100;
    private ActivityMainBinding binding;
    private static final String TAG = "MainActivity";

//    private ActivityResultLauncher<String> requestPermissionLauncher=
//            registerForActivityResult(new ActivityResultContracts.RequestPermission(), new ActivityResultCallback<Boolean>() {
//                @Override
//                public void onActivityResult(Boolean result) {
//                    if(result){
//                        Log.i(TAG, "Granted");
//                    }else{
//                        Log.i(TAG, "Not Granted");
//                    }
//                }
//            });


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding=ActivityMainBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        binding.btnWriteMessage.setOnClickListener(v->{
            String message=binding.etMessage.getText().toString();
            try {
                FileOutputStream fos=openFileOutput(getString(R.string.app_name),MODE_PRIVATE);
                fos.write(message.getBytes());
                fos.close();
                Toast.makeText(this, "File Written Success!!!", Toast.LENGTH_SHORT).show();
            } catch (Exception e) {
                e.printStackTrace();
            }
        });


        binding.btnReadMessage.setOnClickListener(v->{
            try{
                FileInputStream fis=openFileInput(getString(R.string.app_name));
                byte b[]=new byte[fis.available()];
                fis.read(b);
                fis.close();
                String msg=new String(b);
                binding.etMessage.setText(msg);
            }catch (Exception e){
                e.printStackTrace();
            }
        });


        binding.btnWritePreference.setOnClickListener(v->{
            SharedPreferences sharedPrefs=getSharedPreferences(getString(R.string.app_name), MODE_PRIVATE);
            SharedPreferences.Editor editor=sharedPrefs.edit();

            String msg=binding.etMessage.getText().toString();
            editor.putString(MSG,msg);
            editor.putInt(SCORE,700);

            editor.commit();
            Toast.makeText(this, "Shared Preference written!!!", Toast.LENGTH_SHORT).show();

        });

        binding.btnReadPreference.setOnClickListener(v->{
            SharedPreferences sharedPrefs=getSharedPreferences(getString(R.string.app_name), MODE_PRIVATE);

            String msg=sharedPrefs.getString(MSG,null);
            int score=sharedPrefs.getInt(SCORE,0);

            binding.etMessage.setText(msg);
            Log.i(TAG, "Score : "+score);
        });

        binding.btnLogout.setOnClickListener(v->{
            SharedPreferences sharedPrefs=getSharedPreferences(getString(R.string.app_name), MODE_PRIVATE);
            SharedPreferences.Editor editor=sharedPrefs.edit();
            editor.clear();
            editor.commit();

            Intent intent=new Intent(this, LoginActivity.class);
            startActivity(intent);
            finish();
        });


        binding.btnWriteExternal.setOnClickListener(v->{
            String message=binding.etMessage.getText().toString();

            File file=Environment.getExternalStorageDirectory();
            file=new File(file,getString(R.string.app_name));
            if(!file.exists()){
                if(file.mkdir()){
                    Log.i(TAG, "Dir Created");
                }else{
                    Log.i(TAG, "Dir Not Created");
                    return;
                }
            }
            file=new File(file, "test.txt");
            try {
                FileOutputStream fos=new FileOutputStream(file);
                fos.write(message.getBytes());
                fos.close();
                Toast.makeText(this, "File Written Success!!!", Toast.LENGTH_SHORT).show();
            } catch (Exception e) {
                e.printStackTrace();
            }
        });

        binding.btnReadExternal.setOnClickListener(v->{

            File file=Environment.getExternalStorageDirectory();
            file=new File(file,getString(R.string.app_name));
            if(!file.exists()){
                if(file.mkdir()){
                    Log.i(TAG, "Dir Created");
                }else{
                    Log.i(TAG, "Dir Not Created");
                    return;
                }
            }
            file=new File(file, "test.txt");
            try{
                FileInputStream fis=new FileInputStream(file);
                byte b[]=new byte[fis.available()];
                fis.read(b);
                fis.close();
                String msg=new String(b);
                binding.etMessage.setText(msg);
            }catch (Exception e){
                e.printStackTrace();
            }
        });

        // Check Persmission
        checkPermissionAllowDinied();
    }

    private void checkPermissionAllowDinied() {
        if (ContextCompat.checkSelfPermission(this,
                Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
            // permission not grated
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                if(shouldShowRequestPermissionRationale(Manifest.permission.WRITE_EXTERNAL_STORAGE)){
                    // show dialog explain for permission
                    Log.i(TAG, "reason for permission");
                    requestPermissions(
                            new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE},
                            REQ_WRITE_EXTERNAL
                    );
                }else{
                    // directly ask for permission,,, first time app started
                    Log.i(TAG, "ask for permission");
                    //requestPermissionLauncher.launch(Manifest.permission.WRITE_EXTERNAL_STORAGE);

                    requestPermissions(
                            new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE},
                            REQ_WRITE_EXTERNAL
                    );
                }
            }
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if(requestCode==REQ_WRITE_EXTERNAL){
            if(grantResults.length>0 && grantResults[0]==PackageManager.PERMISSION_GRANTED){
                // Permission granted
                Log.i(TAG, "Permission granted");
            }else{
                // Permission not granted
                Log.i(TAG, "Permission not granted");
                binding.btnWriteExternal.setVisibility(View.GONE);
                binding.btnReadExternal.setVisibility(View.GONE);
            }
        }
    }
}