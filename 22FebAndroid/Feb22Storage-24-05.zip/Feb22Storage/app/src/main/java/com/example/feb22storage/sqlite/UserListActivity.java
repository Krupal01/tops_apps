package com.example.feb22storage.sqlite;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.ItemTouchHelper;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.app.AlertDialog;
import android.content.ClipData;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;

import com.example.feb22storage.R;
import com.example.feb22storage.databinding.ActivityUserListBinding;
import com.example.feb22storage.sqlite.adapter.UserAdapter;
import com.example.feb22storage.sqlite.dao.UserDao;
import com.example.feb22storage.sqlite.entities.User;

import java.util.List;

public class UserListActivity extends AppCompatActivity {

    private static final String TAG = "UserListActivity";
    private static final int REQ_NEW_USER = 100;
    private static final int REQ_UPDATE_USER = 200;
    private ActivityUserListBinding binding;
    private List<User> list;
    private UserDao dao;
    private UserAdapter adapter;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding=ActivityUserListBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        AppDatabase db=UtilityHelper.getDataBase(this);
        dao=db.userDao();


        binding.recyclerView.setLayoutManager(new LinearLayoutManager(this));
        adapter=new UserAdapter();

        list = dao.getUsers();
        adapter.setList(list);
        binding.recyclerView.setAdapter(adapter);

        ItemTouchHelper helper=new ItemTouchHelper(new ItemTouchHelper.SimpleCallback(0, ItemTouchHelper.LEFT|ItemTouchHelper.RIGHT) {
            @Override
            public boolean onMove(@NonNull RecyclerView recyclerView, @NonNull RecyclerView.ViewHolder viewHolder, @NonNull RecyclerView.ViewHolder target) {
                return false;
            }

            @Override
            public void onSwiped(@NonNull RecyclerView.ViewHolder viewHolder, int direction) {
                int position=viewHolder.getAdapterPosition();
                if(direction==ItemTouchHelper.LEFT){
                    // Delete operation
                    showConfirmDialog(position);
                }else{
                    // Edit operation
                    Intent intent=new Intent(getApplicationContext(), UserActivity.class);
                    User theUser=list.get(position);
                    intent.putExtra("user",theUser);
                    startActivityForResult(intent, REQ_UPDATE_USER);
                }
            }

            @Override
            public void onChildDraw(@NonNull Canvas c, @NonNull RecyclerView recyclerView,
                                    @NonNull RecyclerView.ViewHolder viewHolder, float dX, float dY,
                                    int actionState, boolean isCurrentlyActive) {
                Paint paint=new Paint();
                View itemView=viewHolder.itemView;
                Bitmap bitmap;
                int height = itemView.getHeight();
                int width=height/3;

                if(actionState==ItemTouchHelper.ACTION_STATE_SWIPE){
                    Log.i(TAG, "DX : "+dX);
                    if(dX>0){
                        // Edit icon with green color
                        paint.setColor(Color.GREEN);
                        c.drawRect(itemView.getLeft(),itemView.getTop(),dX,itemView.getBottom(),paint);
                        bitmap= BitmapFactory.decodeResource(getResources(), android.R.drawable.ic_menu_edit);
                        c.drawBitmap(bitmap,width, itemView.getTop()+width, paint);

                    }else if(dX<0){
                        // Delete icon with red color
                        paint.setColor(Color.RED);
                        c.drawRect(itemView.getRight()+dX,itemView.getTop(),itemView.getRight(),itemView.getBottom(), paint);
                        bitmap= BitmapFactory.decodeResource(getResources(), android.R.drawable.ic_menu_delete);
                        c.drawBitmap(bitmap,itemView.getRight()-(width*2), itemView.getTop()+width, paint);
                    }
                }
                super.onChildDraw(c, recyclerView, viewHolder, dX, dY, actionState, isCurrentlyActive);

            }
        });
        helper.attachToRecyclerView(binding.recyclerView);
    }

    private void showConfirmDialog(int position) {
        new AlertDialog.Builder(this)
                .setTitle(getString(R.string.app_name))
                .setMessage("Are you sure want to Delete?")
                .setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        User theUser = list.get(position);
                        dao.deleteUser(theUser);

                        list = dao.getUsers();
                        adapter.setList(list);
                        adapter.notifyDataSetChanged();

                    }
                })
                .setNegativeButton("No", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        adapter.notifyDataSetChanged();
                    }
                })
                .create().show();
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.user_menu,menu);
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        if(item.getItemId()==R.id.action_new){
            Intent intent=new Intent(this, UserActivity.class);
            startActivityForResult(intent, REQ_NEW_USER);
            return true;
        }
        return super.onOptionsItemSelected(item);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        // call when we back with result
        if(requestCode==REQ_NEW_USER){
            if(resultCode==RESULT_OK){
                // User Inserted successfully... fetch new Data

                User theUser=data.getParcelableExtra("user");
                Log.i(TAG, "User is Saved : "+theUser.id);

                list = dao.getUsers();
                adapter.setList(list);
                adapter.notifyDataSetChanged();
            }
        }
        else if(requestCode==REQ_UPDATE_USER && resultCode==RESULT_OK){
            list = dao.getUsers();
            adapter.setList(list);
            adapter.notifyDataSetChanged();
        }
    }
}