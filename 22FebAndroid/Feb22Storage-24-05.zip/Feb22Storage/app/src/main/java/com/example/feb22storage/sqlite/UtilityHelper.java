package com.example.feb22storage.sqlite;

import android.content.Context;

import androidx.room.Room;

import com.example.feb22storage.R;

public class UtilityHelper {
    private static AppDatabase db;
    public static AppDatabase getDataBase(Context context){
        if(db==null) {
            db = Room.databaseBuilder(context,
                    AppDatabase.class, context.getString(R.string.app_name))
                    .allowMainThreadQueries()
                    .build();
        }
        return db;
    }
}
