package com.example.android_paging.data

data class news(
    val news: List<New>,
    val status: Boolean,
    val total_pages: Int
)