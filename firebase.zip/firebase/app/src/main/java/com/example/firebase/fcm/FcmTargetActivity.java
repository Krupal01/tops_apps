package com.example.firebase.fcm;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import com.example.firebase.R;

public class FcmTargetActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_fcm_target);
    }
}