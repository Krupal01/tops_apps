package com.example.firebase.media;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import com.example.firebase.R;

public class MusicFromServerActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_music_from_server);
    }
}