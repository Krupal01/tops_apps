package com.example.assignmenttopsonline.retrofit;

import androidx.appcompat.app.AppCompatActivity;

import android.app.ProgressDialog;
import android.os.Bundle;
import android.util.Log;
import android.widget.ArrayAdapter;

import com.example.assignmenttopsonline.R;
import com.example.assignmenttopsonline.databinding.ActivityRetrofitRootBinding;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

import java.util.ArrayList;
import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;
import retrofit2.converter.scalars.ScalarsConverterFactory;

public class RetrofitRootActivity extends AppCompatActivity {
    private ActivityRetrofitRootBinding binding;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding=ActivityRetrofitRootBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        getHeroes();
    }
    private void getHeroes() {
        Call<List<HeroData>> call=RetrofitClient.getInstance().getService().getHeroData();

        call.enqueue(new Callback<List<HeroData>>() {
            @Override
            public void onResponse(Call<List<HeroData>> call, Response<List<HeroData>> response) {

                List<HeroData>heroes=response.body();


                Log.i("Response",response.body().toString());

                ArrayAdapter<HeroData>arrayAdapter=new ArrayAdapter<>(getApplicationContext(), android.R.layout.simple_list_item_1,heroes);
                binding.listViewRetroFit.setAdapter(arrayAdapter);
                arrayAdapter.notifyDataSetChanged();

            }

            @Override
            public void onFailure(Call<List<HeroData>> call, Throwable t) {
                Log.i("error",t.toString());
            }
        });
    }
}