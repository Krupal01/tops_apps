package com.example.assignmenttopsonline.gson.railway;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.assignmenttopsonline.databinding.GsonRailwayRowItemBinding;
import com.example.assignmenttopsonline.gson.railway.gson_classes.RecordsItem;

import org.jetbrains.annotations.NotNull;

import java.util.ArrayList;
import java.util.List;

public class RailwayAdapter extends RecyclerView.Adapter<RailwayAdapter.RailwayViewHolder> {
    List<RecordsItem> items;

    public void setItems(List<RecordsItem> items) {
        this.items = items;
    }

    @NotNull
    @Override
    public RailwayViewHolder onCreateViewHolder(@NonNull @NotNull ViewGroup parent, int viewType) {
        LayoutInflater inflater=LayoutInflater.from(parent.getContext());
        GsonRailwayRowItemBinding binding=GsonRailwayRowItemBinding.inflate(inflater,parent,false);
        RailwayViewHolder viewHolder=new RailwayViewHolder(binding);
        return viewHolder;
    }

    @Override
    public void onBindViewHolder(@NonNull @NotNull RailwayViewHolder holder, int position) {
        RecordsItem item=items.get(position);
        holder.binding.setData(item);
    }

    @Override
    public int getItemCount() {
        return items.size();
    }

    public class RailwayViewHolder extends RecyclerView.ViewHolder {
        private GsonRailwayRowItemBinding binding;
        public RailwayViewHolder(@NonNull GsonRailwayRowItemBinding binding) {
            super(binding.getRoot());
            this.binding=binding;
        }
    }
}
