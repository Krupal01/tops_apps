package com.example.assignmenttopsonline.gson.railway.gson_classes;

import com.google.gson.annotations.SerializedName;

public class RecordsItem{

	@SerializedName("metre_gauge")
	private String metreGauge;

	@SerializedName("_total")
	private String total;

	@SerializedName("narrow_gauge")
	private String narrowGauge;

	@SerializedName("_year")
	private String year;

	@SerializedName("broad_gauge")
	private String broadGauge;

	public String getMetreGauge(){
		return metreGauge;
	}

	public String getTotal(){
		return total;
	}

	public String getNarrowGauge(){
		return narrowGauge;
	}

	public String getYear(){
		return year;
	}

	public String getBroadGauge(){
		return broadGauge;
	}

	@Override
 	public String toString(){
		return 
			"RecordsItem{" + 
			"metre_gauge = '" + metreGauge + '\'' + 
			",_total = '" + total + '\'' + 
			",narrow_gauge = '" + narrowGauge + '\'' + 
			",_year = '" + year + '\'' + 
			",broad_gauge = '" + broadGauge + '\'' + 
			"}";
		}
}