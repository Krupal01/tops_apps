package com.example.assignmenttopsonline.parse_api.cricket;

import androidx.appcompat.app.AppCompatActivity;

import android.app.ProgressDialog;
import android.os.Bundle;
import android.util.Log;
import android.widget.ArrayAdapter;

import com.android.volley.RequestQueue;
import com.example.assignmenttopsonline.databinding.ActivityCricketApiactivityBinding;
import com.example.assignmenttopsonline.parse_api.MyAsyncTask;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;

public class CricketAPIActivity extends AppCompatActivity implements MyAsyncTask.onResponseListener {
    private ActivityCricketApiactivityBinding binding;
    private ProgressDialog pd;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setTitle("UpComing Matches");
        binding = ActivityCricketApiactivityBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        pd=ProgressDialog.show(this,"Wait","Fetching Data");

        MyAsyncTask asyncTask = new MyAsyncTask();
        asyncTask.setUrl("https://cricapi.com/api/matches?apikey=cZGPAxS3TQNPuiG3DmK6slHvyEk2");
        asyncTask.setListener(this);
        asyncTask.execute();

    }
    @Override
    public void onResponse(String response) {

        pd.dismiss();

//        binding.tvResponse.setText(response);

        ArrayList<CricketData>dataArrayList=new ArrayList<>();
        try {

            //there is object first .. and array inside the object so.... take response in object

            JSONObject masterObject=new JSONObject(response);
            JSONArray jsonArray=masterObject.getJSONArray("matches");

            for(int i=0;i<jsonArray.length();i++){

                JSONObject object=jsonArray.getJSONObject(i);

                String date=object.getString("date");
                String trimDate = date.substring(0, Math.min(date.length(), 10));
                String team1=object.getString("team-1");
                String team2=object.getString("team-2");
                CricketData jsonData=new CricketData(trimDate,team1,team2);
                dataArrayList.add(jsonData);

            }
            ArrayAdapter<CricketData>adapter=new ArrayAdapter<>(getApplicationContext(), android.R.layout.simple_list_item_1,dataArrayList);
            binding.listViewCricket.setAdapter(adapter);

        }catch (Exception e){
            Log.i("hi",e.toString());

        }
    }
}