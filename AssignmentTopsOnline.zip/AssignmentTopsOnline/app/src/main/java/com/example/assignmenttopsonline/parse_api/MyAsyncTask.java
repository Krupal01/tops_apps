package com.example.assignmenttopsonline.parse_api;

import android.os.AsyncTask;
import android.util.Log;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;

import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;

public class MyAsyncTask extends AsyncTask<String,Void,String> {

    private onResponseListener listener;
    public void setListener(onResponseListener listener) {
        this.listener = listener;
    }
    public interface onResponseListener{
        void onResponse(String response);
    }

    private String url;
    public void setUrl(String url) {
        this.url = url;
    }

    @Override
    protected void onPreExecute() {
        super.onPreExecute();
    }

    @Override
    protected String doInBackground(String... strings) {
        String response=fetchDataFromUrl(url);
        return response;
//        OkHttpClient client=new OkHttpClient();
//        Request request=new Request.Builder()
//                .url(url)
//                .build();
//        try{
//            Response response=client.newCall(request).execute();
//            return response.body().string();
//
//        }catch (IOException e){
//            Log.i("error",e.toString());
//        }
//        return null;
    }

    @Override
    protected void onPostExecute(String s) {
        super.onPostExecute(s);
        listener.onResponse(s);
    }

    @Override
    protected void onProgressUpdate(Void... values) {
        super.onProgressUpdate(values);
    }

    private String fetchDataFromUrl(String url) {
        try {
            URL theUrl = new URL(url);
            HttpURLConnection connection= (HttpURLConnection) theUrl.openConnection();
            connection.setReadTimeout(30000);
            connection.setConnectTimeout(60000);

            int responseCode= connection.getResponseCode();
            String response="";

            if(responseCode==HttpURLConnection.HTTP_OK){
                BufferedReader br=new BufferedReader(new InputStreamReader(connection.getInputStream()));
                String line;
                while((line=br.readLine())!=null){
                    response+=line;
                }
            }else if(responseCode==HttpURLConnection.HTTP_INTERNAL_ERROR){
                BufferedReader br=new BufferedReader(new InputStreamReader(connection.getInputStream()));
                String line;
                while((line=br.readLine())!=null){
                    response+=line;
                }

            }
            return response;

        }catch (Exception e){
            return e.toString();
        }
    }
}
