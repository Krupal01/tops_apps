package com.example.assignmenttopsonline.parse_api.railway;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.assignmenttopsonline.databinding.RailwayRowItemBinding;

import org.jetbrains.annotations.NotNull;

import java.util.ArrayList;

public class RailwayAdapter extends RecyclerView.Adapter<RailwayAdapter.RailwayViewHolder> {

    ArrayList<RailwayData>dataArrayList;

    public RailwayAdapter(ArrayList<RailwayData>dataArrayList){
        this.dataArrayList=dataArrayList;
    }
    @NotNull
    @Override
    public RailwayViewHolder onCreateViewHolder(@NonNull @NotNull ViewGroup parent, int viewType) {
        LayoutInflater inflater=LayoutInflater.from(parent.getContext());
        RailwayRowItemBinding binding=RailwayRowItemBinding.inflate(inflater,parent,false);
        RailwayViewHolder viewHolder=new RailwayViewHolder(binding);
        return viewHolder;
    }

    @Override
    public void onBindViewHolder(@NonNull @NotNull RailwayViewHolder holder, int position) {

        RailwayData data=dataArrayList.get(position);
        holder.binding.setData(data);

    }

    @Override
    public int getItemCount() {
        return dataArrayList.size();
    }

    public class RailwayViewHolder extends RecyclerView.ViewHolder {
        private RailwayRowItemBinding binding;
        public RailwayViewHolder(@NonNull RailwayRowItemBinding binding) {
            super(binding.getRoot());
            this.binding=binding;
        }
    }
}
