package com.example.assignmenttopsonline.gson.cricket.gson_classes;

import java.util.List;
import com.google.gson.annotations.SerializedName;

public class Cricket{

	@Override
	public String toString() {
		return "Cricket{" +
				"creditsLeft=" + creditsLeft +
				", provider=" + provider +
				", V='" + V + '\'' +
				", matches=" + matches +
				", ttl=" + ttl +
				'}';
	}

	@SerializedName("creditsLeft")
	private int creditsLeft;

	@SerializedName("provider")
	private Provider provider;

	@SerializedName("v")
	private String V;

	@SerializedName("matches")
	private List<MatchesItem> matches;

	@SerializedName("ttl")
	private int ttl;

	public int getCreditsLeft(){
		return creditsLeft;
	}

	public Provider getProvider(){
		return provider;
	}

	public String getV(){
		return V;
	}

	public List<MatchesItem> getMatches(){
		return matches;
	}

	public int getTtl(){
		return ttl;
	}
}