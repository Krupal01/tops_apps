package com.example.assignmenttopsonline.gson.railway;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;

import android.os.Bundle;
import android.util.Log;

import com.example.assignmenttopsonline.R;
import com.example.assignmenttopsonline.databinding.ActivityRailwayGsonBinding;
import com.example.assignmenttopsonline.gson.railway.gson_classes.Railway;
import com.example.assignmenttopsonline.gson.railway.gson_classes.RecordsItem;
import com.google.gson.Gson;

import org.jetbrains.annotations.NotNull;

import java.io.IOException;
import java.util.List;

import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;

public class RailwayGsonActivity extends AppCompatActivity {
    private ActivityRailwayGsonBinding binding;
    private OkHttpClient client=new OkHttpClient();
    private List<RecordsItem>recordsItemList;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding=ActivityRailwayGsonBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        binding.recyclerViewRailwayGson.setLayoutManager(new LinearLayoutManager(this));

        String url="https://api.data.gov.in/resource/7be53d59-08e0-4247-b7c5-1a9fb220720a?api-key=579b464db66ec23bdd000001cdd3946e44ce4aad7209ff7b23ac571b&format=json&offset=0&limit=1000";

        getPerson(url);
    }

    private void getPerson(String url) {
        Request request=new Request.Builder()
                .url(url)
                .build();
        client.newCall(request).enqueue(new Callback() {
            @Override
            public void onFailure(@NotNull Call call, @NotNull IOException e) {
                e.printStackTrace();
            }

            @Override
            public void onResponse(@NotNull Call call, @NotNull Response response) throws IOException {
                Log.i("hi",response.toString());
                if(response.isSuccessful()){
                    new Thread(new Runnable() {
                        @Override
                        public void run() {
                            Gson gson=new Gson();
                            Railway item=gson.fromJson(response.body().charStream(),Railway.class);
                            recordsItemList=item.getRecords();
                            runOnUiThread(new Runnable() {
                                @Override
                                public void run() {
                                    RailwayAdapter adapter=new RailwayAdapter();
                                    adapter.setItems(recordsItemList);
                                    binding.recyclerViewRailwayGson.setAdapter(adapter);
                                }
                            });
                        }
                    }).start();

                }
            }
        });


    }
}