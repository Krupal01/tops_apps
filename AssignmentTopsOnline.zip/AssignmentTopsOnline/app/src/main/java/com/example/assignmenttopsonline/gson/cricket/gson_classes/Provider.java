package com.example.assignmenttopsonline.gson.cricket.gson_classes;

import com.google.gson.annotations.SerializedName;

public class Provider{
	@Override
	public String toString() {
		return "Provider{" +
				"source='" + source + '\'' +
				", pubDate='" + pubDate + '\'' +
				", url='" + url + '\'' +
				'}';
	}

	@SerializedName("source")
	private String source;

	@SerializedName("pubDate")
	private String pubDate;

	@SerializedName("url")
	private String url;

	public String getSource(){
		return source;
	}

	public String getPubDate(){
		return pubDate;
	}

	public String getUrl(){
		return url;
	}
}