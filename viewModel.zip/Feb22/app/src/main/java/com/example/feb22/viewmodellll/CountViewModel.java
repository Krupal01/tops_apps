package com.example.feb22.viewmodellll;

import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;

public class CountViewModel extends ViewModel {
        private MutableLiveData<Integer> count;
        public LiveData<Integer> getCount(){
            if(count==null){
                count=new MutableLiveData<>();
                count.setValue(1);
            }
            return count;
        }
        public void increaseCounter(){
            count.setValue(count.getValue()+1);
        }
}
