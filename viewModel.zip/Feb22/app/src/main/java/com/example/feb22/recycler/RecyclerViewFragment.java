package com.example.feb22.recycler;

import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.DividerItemDecoration;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.StaggeredGridLayoutManager;

import android.view.ActionMode;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;

import com.example.feb22.R;
import com.example.feb22.databinding.FragmentRecyclerViewBinding;

import java.lang.reflect.Array;
import java.util.ArrayList;

/**
 * A simple {@link Fragment} subclass.
 * Use the {@link RecyclerViewFragment#newInstance} factory method to
 * create an instance of this fragment.
 */
public class RecyclerViewFragment extends Fragment implements PersonAdapter.OnPersonClickListener {

    // TODO: Rename parameter arguments, choose names that match
    // the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
    private static final String ARG_PARAM1 = "param1";
    private static final String ARG_PARAM2 = "param2";



    // TODO: Rename and change types of parameters
    private String mParam1;
    private String mParam2;
    private ArrayList<Person> people;
    private PersonAdapter adapter;

    public RecyclerViewFragment() {
        // Required empty public constructor
    }

    /**
     * Use this factory method to create a new instance of
     * this fragment using the provided parameters.
     *
     * @param param1 Parameter 1.
     * @param param2 Parameter 2.
     * @return A new instance of fragment RecyclerView_Fragment.
     */
    // TODO: Rename and change types and number of parameters
    public static RecyclerViewFragment newInstance(String param1, String param2) {
        RecyclerViewFragment fragment = new RecyclerViewFragment();
        Bundle args = new Bundle();
        args.putString(ARG_PARAM1, param1);
        args.putString(ARG_PARAM2, param2);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            mParam1 = getArguments().getString(ARG_PARAM1);
            mParam2 = getArguments().getString(ARG_PARAM2);
        }
    }

    private FragmentRecyclerViewBinding binding;

    private ActionMode actionMode;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment

        binding=FragmentRecyclerViewBinding.inflate(inflater,container,false);
        return binding.getRoot();
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        /* set Layout Manager : confirms how you want to arrange data in recyclerview
            1. LinearLayoutManager :  vertical(by default), horizontal
            2. GridLayoutManager :
            3. StaggeredGridLayoutManager
         */

        // Step 1 : set Layout manager
        /*LinearLayoutManager layoutManager =
                new LinearLayoutManager(getContext(),LinearLayoutManager.HORIZONTAL,true);*/
        LinearLayoutManager layoutManager =
                new LinearLayoutManager(getContext());
        /*GridLayoutManager layoutManager=new GridLayoutManager(getContext(),2);*/
        /*StaggeredGridLayoutManager layoutManager=
                new StaggeredGridLayoutManager(2,StaggeredGridLayoutManager.VERTICAL);*/
        binding.recyclerView.setLayoutManager(layoutManager);

        // Step 2 : Prepare data
        people=new ArrayList<>();
        people.add(new Person("Ankit","Sodha","ankit@gmail.com"));
        people.add(new Person("Devang","Sodha","devang@gmail.com"));
        people.add(new Person("Mayuri","Sodha","mayuri@gmail.com"));
        people.add(new Person("Kavya","Sodha","kavya@gmail.com"));


        // add separator
        /*DividerItemDecoration dividerItemDecoration =
                new DividerItemDecoration(binding.recyclerView.getContext(),layoutManager.getOrientation());
        binding.recyclerView.addItemDecoration(dividerItemDecoration);*/

        // Step 3 : Create Adapter Class

        // Step 4 : pass data to Adapter class
        adapter=new PersonAdapter(this);
        adapter.setPeople(people);

        // Step 5 : set Adapter
        binding.recyclerView.setAdapter(adapter);

    }

    @Override
    public void onPersonLongClick(int position) {
        if(actionMode==null){
            actionMode=getActivity().startActionMode(actionModeCallback);
        }
        toggleSelection(position);
    }

    @Override
    public void onPersonClick(int position) {
        if(actionMode!=null){
            toggleSelection(position);
        }
    }

    private void toggleSelection(int position) {
        // select - deselect logic
        people.get(position).setColored(!people.get(position).isColored());

        // count selected item
        int count=0;
        for(Person person:people){
            if(person.isColored()){
                count++;
            }
        }
        if(count==0){
            actionMode.finish();
            actionMode=null;
        }else {
            actionMode.setTitle("Total : " + count);
        }

        adapter.notifyDataSetChanged();
    }

    ActionMode.Callback actionModeCallback = new ActionMode.Callback(){

        @Override
        public boolean onCreateActionMode(ActionMode mode, Menu menu) {
            mode.getMenuInflater().inflate(R.menu.delete_menu,menu);
            return true;
        }

        @Override
        public boolean onPrepareActionMode(ActionMode mode, Menu menu) {
            return false;
        }

        @Override
        public boolean onActionItemClicked(ActionMode mode, MenuItem item) {
            if(item.getItemId()==R.id.action_delete){
                // ====== Delete Selected Items========
                ArrayList<Person> tempList=new ArrayList<>();
                tempList.addAll(people);
                for(Person person : tempList){
                    if(person.isColored()){
                        people.remove(person);
                    }
                }
                adapter.notifyDataSetChanged();
                mode.finish();
                return true;
            }
            return false;
        }

        @Override
        public void onDestroyActionMode(ActionMode mode) {
            // clear selection
            for(int i=0;i<people.size();i++){
                people.get(i).setColored(false);
            }
            adapter.notifyDataSetChanged();
            //---------
            actionMode = null;
        }
    };
}