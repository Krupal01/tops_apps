package com.example.feb22.navigate;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import com.example.feb22.R;

public class NavigationHomeActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_navigation_home);
    }
}