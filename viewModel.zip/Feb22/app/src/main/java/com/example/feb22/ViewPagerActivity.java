package com.example.feb22;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentStatePagerAdapter;
import androidx.viewpager.widget.ViewPager;

import android.os.Bundle;

import com.example.feb22.adapter.MyPagerAdapter;
import com.example.feb22.databinding.ActivityViewPagerBinding;
import com.example.feb22.fragments.CheckboxFragment;
import com.example.feb22.fragments.CustomLayoutFragment;
import com.example.feb22.fragments.DialogsFragment;

import java.util.ArrayList;

public class ViewPagerActivity extends AppCompatActivity {
    private ActivityViewPagerBinding binding;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding=ActivityViewPagerBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        // data => ArrayList<Fragment>

        ArrayList<Fragment> fragments=new ArrayList<>();
        fragments.add(new CheckboxFragment());
        fragments.add(new CustomLayoutFragment());
        fragments.add(new DialogsFragment());
        fragments.add(new CheckboxFragment());
        fragments.add(new CustomLayoutFragment());
        fragments.add(new DialogsFragment());

        ArrayList<String> titles=new ArrayList<>();
        titles.add("Checkbox");
        titles.add("CustomLayout");
        titles.add("Dialogs");
        titles.add("Checkbox");
        titles.add("CustomLayout");
        titles.add("Dialogs");

        // create Adapter
        MyPagerAdapter adapter=new MyPagerAdapter(getSupportFragmentManager(), fragments, titles);
        binding.viewPager.setAdapter(adapter);

        binding.tabLayout.setupWithViewPager(binding.viewPager);

        binding.viewPager.addOnPageChangeListener(new ViewPager.OnPageChangeListener() {
            @Override
            public void onPageScrolled(int position, float positionOffset, int positionOffsetPixels) {

            }

            @Override
            public void onPageSelected(int position) {
                setTitle(titles.get(position));
            }

            @Override
            public void onPageScrollStateChanged(int state) {

            }
        });
    }



}