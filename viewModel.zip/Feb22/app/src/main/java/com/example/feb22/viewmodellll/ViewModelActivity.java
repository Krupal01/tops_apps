package com.example.feb22.viewmodellll;

import androidx.appcompat.app.AppCompatActivity;
import androidx.lifecycle.Observer;
import androidx.lifecycle.ViewModelProvider;

import android.os.Bundle;

import com.example.feb22.databinding.ActivityViewModelBinding;

public class ViewModelActivity extends AppCompatActivity {
    //private int count=1;
    private ActivityViewModelBinding binding;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding=ActivityViewModelBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        CountViewModel countModel=new ViewModelProvider(this).get(CountViewModel.class);
        countModel.getCount().observe(this, new Observer<Integer>() {
            @Override
            public void onChanged(Integer integer) {
                binding.tvCount.setText("Count : "+integer);
            }
        });

        binding.btnCount.setOnClickListener(v->{
            countModel.increaseCounter();
        });
    }
}