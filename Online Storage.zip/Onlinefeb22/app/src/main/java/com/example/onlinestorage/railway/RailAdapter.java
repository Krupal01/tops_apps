package com.example.onlinestorage.railway;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.onlinestorage.R;

import org.jetbrains.annotations.NotNull;

import java.util.ArrayList;
import java.util.zip.Inflater;

public class RailAdapter extends RecyclerView.Adapter<RailAdapter.RailViewHolder> {

    private ArrayList<RailObject> Rail;

    public void setRail(ArrayList<RailObject> rail) {
        Rail = rail;
    }

    @NonNull
    @NotNull
    @Override
    public RailAdapter.RailViewHolder onCreateViewHolder(@NonNull @NotNull ViewGroup parent, int viewType) {
        LayoutInflater inflater = LayoutInflater.from(parent.getContext());
        View view = inflater.inflate(R.layout.custom1,parent,false);
        RailViewHolder viewHolder = new RailViewHolder(view);
        return viewHolder;
    }

    @Override
    public void onBindViewHolder(@NonNull @NotNull RailAdapter.RailViewHolder holder, int position) {
        holder.Id.setText(Rail.get(position).getId());
        holder.UserId.setText(Rail.get(position).getUserId());
        holder.title.setText(Rail.get(position).getTitle());
        holder.body.setText(Rail.get(position).getBody());
    }

    @Override
    public int getItemCount() {
        return Rail.size();
    }

    public class RailViewHolder extends RecyclerView.ViewHolder {
        public TextView Id,UserId,title,body;
        public RailViewHolder(@NonNull @NotNull View itemView) {
            super(itemView);
            this.Id = itemView.findViewById(R.id.Id);
            this.UserId = itemView.findViewById(R.id.UserID);
            this.title = itemView.findViewById(R.id.Title);
            this.body = itemView.findViewById(R.id.body);
        }
    }
}
